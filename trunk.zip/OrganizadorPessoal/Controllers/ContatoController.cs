﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.ContatoVM;
using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter]
    public class ContatoController : Controller
    {
        public ActionResult Index()
        {

            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);


            ContatoService contatoservice = new ContatoService();

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;
            var contatosUsuario = contatoservice.Listar(idUsuario, idGrupo);

            ContatoIndexVM vm = new ContatoIndexVM();
            vm.ListaContato = contatosUsuario;

            return View(vm);
        }


        public ActionResult Cadastrar()
        {
            return View(new ContatoCadastrarVM());
        }


        [HttpPost]
        public ActionResult Cadastrar(ContatoCadastrarVM vm)
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            ContatoService contatoservice = new ContatoService();
            
            // Primeiro nível de validação
            // onde valida apenas os campos da VM
            if (ModelState.IsValid)
            {

                CONTATO contato = new CONTATO();
                contato.IdUsuarioProprietario = sessaoUsuario.Usuario.IdUsuario;
                contato.IdGrupoProprietario = sessaoUsuario.Grupo.IdGrupo;
                contato.Nome = vm.Nome;
                contato.Email = vm.Email;
                contato.Apelido = vm.Apelido;
                DateTime dataNascimento;
                contato.DataNascimento = DateTime.TryParse(vm.DataNascimeto, out dataNascimento) ? dataNascimento : (DateTime?)null;
                string telefone = vm.Telefone;
                if (telefone != null)
                    telefone = telefone.Replace("(", "").Replace(")", "").Replace(" ", "");
                contato.Telefone = telefone;
                contato.Endereco = vm.Endereco;
                contato.FlagAtivo = "S";

                var erros = contatoservice.ValidaAdicionar(contato);
                if (erros.Count == 0)
                {
                    contatoservice.Adicionar(contato, vm.ConvidarParaOgrupo, vm.PermitirConvidarMembros);
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelErrors(erros);
                    return View(vm);
                }


                
            }

            return View(vm);

        }

        public ActionResult Desativar(int id)
        {
            ContatoService contatoservice = new ContatoService();
            contatoservice.Remover(id);
            return RedirectToAction("Index");
        }

        public PartialViewResult Detalhe(int id)
        {
            ContatoService contatoservice = new ContatoService();
            CONTATO contato = contatoservice.Detalhes(id);
            return PartialView("_Detalhe",contato);
        }

    }
}
