﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.GrupoVM;
using OrganizadorPessoal.Filtros;

namespace OrganizadorPessoal.Controllers
{
    // Esse controller de gupo é especifico para gerenciamento do administrador
    [AutenticacaoFilter("A")]
    public class GrupoController : Controller
    {

        public ActionResult Index()
        {
            GrupoService grupoService = new GrupoService();
            var grupos = grupoService.Listar();

            GrupoIndexVM vm = new GrupoIndexVM();
            vm.Registros = grupos;

            return View(vm);
        }

        public ActionResult Cadastrar()
        {
            return View(new GrupoCadastrarVM());
        }

        [HttpPost]
        public ActionResult Cadastrar(GrupoCadastrarVM vm)
        {
            if (ModelState.IsValid)
            {
                string nome = vm.Nome;
                string emailAdministradorGrupo = vm.EmailAdmin;

                // Imagem do grupo
                string imagemGrupoBase64 = vm.ImagemGrupoBase64;
                byte[] bytesImagem = null;
                if (imagemGrupoBase64 != null)
                {
                    bytesImagem = Convert.FromBase64String(imagemGrupoBase64);
                }


                
                GrupoService grupoService = new GrupoService();
                List<ValidationResult> erros = grupoService.ValidarNomeDoGrupo(nome);
                if (erros.Count.Equals(0))
                {
                    grupoService.AdicionarAdminGrupo(nome, emailAdministradorGrupo, bytesImagem);
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelErrors(erros);
                }

            }

            return View(vm);
        }

        public PartialViewResult ListaUsuariosGrupo(int id)
        {
            GrupoListaUsuariosVM vm = new GrupoListaUsuariosVM();
            GrupoService gruposervice = new GrupoService();
            vm.ListaUsuarios = gruposervice.ListarUsuariosAtivosDoGrupo(id);

            return PartialView("_ListaUsuarioGrupo", vm);
        }
    }
}
