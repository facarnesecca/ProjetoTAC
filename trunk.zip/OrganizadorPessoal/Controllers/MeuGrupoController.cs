﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.MeuGrupoVM;
using OrganizadorPessoal.Filtros;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter]
    public class MeuGrupoController : Controller
    {
        public ActionResult Index()
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            GrupoService grupoService = new GrupoService();
            var usuariosDoGrupo = grupoService.ListarUsuariosAtivosDoGrupo(sessaoUsuario.Grupo.IdGrupo);

            MeuGrupoIndex vm = new MeuGrupoIndex();
            vm.ListaUsuario = usuariosDoGrupo;
            vm.GrupoSessao = sessaoUsuario.Grupo;
            vm.UsuarioSessao = sessaoUsuario.Usuario;
            
            return View(vm);
        }


        // Id do usuário
        public ActionResult Desativar(int id)
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idGrupo = sessaoUsuario.Grupo.IdGrupo;

            GrupoService grupoService = new GrupoService();
            grupoService.DesativarUsuarioNoGrupo(idGrupo, id);

            return RedirectToAction("Index");
        }

    }
}
