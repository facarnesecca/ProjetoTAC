﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.ViewModels;
using OrganizadorPessoal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrganizadorPessoal.Models.Services;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter]
    public class TarefaController : Controller
    {
        TarefaService tarefaService;

        public TarefaController()
        {
            tarefaService = new TarefaService();
        }

        public ActionResult Index()
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;
            var tarefasUsuario = tarefaService.ListarTarefasPendentes(idUsuario, idGrupo);

            TarefaIndexVM vm = new TarefaIndexVM();
            vm.ListaTarefas = tarefasUsuario;
            vm.TarefaCondicao = "pendentes";

            return View(vm);
        }

        [HttpPost]
        public ActionResult Index(TarefaIndexVM vm)
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;

            if (vm.TarefaCondicao.Equals("delegadas"))
                vm.ListaTarefas = tarefaService.ListarTarefasDelegadas(idUsuario, idGrupo);
            else if (vm.TarefaCondicao.Equals("pendentes"))
                vm.ListaTarefas = tarefaService.ListarTarefasPendentes(idUsuario, idGrupo);
            else // Concluídas
                vm.ListaTarefas = tarefaService.ListarTarefasConcluidas(idUsuario, idGrupo);

            return View(vm);
        }

        public ActionResult Cadastrar(string dia, string idCompromisso, string idExecutor)
        {
            TarefaCadastrarVM vm = TarefaCadastrarVM.ConstruirFormParaNovo();
            if (dia != null)
                vm.DataHoraInicio = dia;
            else
                vm.DataHoraInicio = DateTime.Now.Date.ToShortDateString();

            // Compromisso associado
            if (idCompromisso != "")
                vm.IdCompromisso = idCompromisso;
            if (idExecutor != "")
                vm.IdExecutor = idExecutor;
                

            return View(vm);
        }

        [HttpPost]
        public ActionResult Cadastrar(TarefaCadastrarVM vm)
        {
            if (ModelState.IsValid)
            {
                TAREFA tarefa = TarefaCadastrarVM.ConverterTarefaVM(vm);
                List<ValidationResult> erros = tarefaService.ValidarAdicionarTarefa(tarefa);
                
                if (erros.Count == 0)
                {
                    tarefaService.Adicionar(tarefa);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelErrors(erros);
                }
            }
            TarefaCadastrarVM.PopularItens(vm);
            return View(vm);
        }

        [HttpPost]
        public ActionResult AssociarCompromisso(string dia, string idCompromisso, string idExecutor)
        {

            return RedirectToAction("Cadastrar", new { dia = dia, idCompromisso = idCompromisso, idExecutor = idExecutor });
        }

        [HttpPost]
        public ActionResult Consultar(int id)
        {

            TAREFA registro = tarefaService.BuscarPorId(id);
            TarefaCadastrarVM vm = TarefaCadastrarVM.ConverterTarefaVM(registro);

            return View(vm);
        }

        [HttpPost]
        public ActionResult Atualizar(string idTarefa, string observacao)
        {
            int id = int.Parse(idTarefa);
            
            TAREFA tarefa = tarefaService.BuscarPorId(id);
            tarefa.Observacao = observacao;
            List<ValidationResult> erros = tarefaService.ValidarAtualizarTarefa(tarefa);
            
            TarefaCadastrarVM vm = TarefaCadastrarVM.ConverterTarefaVM(tarefa);

            if (erros.Count == 0)
            {
                tarefa = tarefaService.Atualizar(id, observacao);
                
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelErrors(erros);
            }
            
            return View("Consultar", vm);
        }

        public ActionResult Desativar(int id)
        {
            
            tarefaService.Desativar(id);

            return RedirectToAction("Index", "Home");
        }

        public ActionResult AtualizarEstado(string idTarefa, string estado)
        {
            int id = int.Parse(idTarefa);
            TAREFA tarefa = tarefaService.BuscarPorId(id);

            if (ModelState.IsValid)
            {
                tarefa = tarefaService.AtualizarEstado(id, estado);
            }

            TarefaCadastrarVM vm = TarefaCadastrarVM.ConverterTarefaVM(tarefa);

            if (estado == "A" || estado == "C")
                return View("Consultar", vm);
            else
                return RedirectToAction("Index", "Tarefa");
            
        }
    }
}
