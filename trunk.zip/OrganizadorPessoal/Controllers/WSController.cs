﻿using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.Models.ws;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OrganizadorPessoal.Controllers
{
    public class WSController : ApiController
    {
        private const string FORMATO_DATE_TIME = "dd/MM/yyyy HH:mm";

        [HttpGet] 
        public UsuarioWS GetUsuario(string token, string dados)
        {
            UsuarioWS usuarioWS = null;

            if (validarToken(token))
            {
                UsuarioService usuarioService = new UsuarioService();
                string dadosDecriptados = null;
                try
                {
                    dadosDecriptados = Crypto.Decrypt(dados);
                }
                catch (Exception)
                {
                    return null;
                }
                
                string[] splitDados = dadosDecriptados.Split(';');

                USUARIO usuario = usuarioService.BuscarPorEmailSenha(splitDados[0], splitDados[1]);
                if (usuario != null)
                {
                    usuarioWS = new UsuarioWS();
                    usuarioWS.IdUsuario = usuario.IdUsuario;
                    usuarioWS.Nome = usuario.Nome;
                    usuarioWS.Email = usuario.Email;
                }
            }

            return usuarioWS;
        }

        [HttpGet]
        public IEnumerable<GrupoWS> GetGrupos(string token, int idUsuario)
        {
            List<GrupoWS> gruposWS = null;

            if (validarToken(token))
            {
                GrupoService grupoService = new GrupoService();
                List<GRUPO> grupos = grupoService.ListarGruposDoUsuario(idUsuario);

                gruposWS = new List<GrupoWS>();
                foreach (var item in grupos)
                {
                    GrupoWS grupoWS = new GrupoWS();
                    grupoWS.IdGrupo = item.IdGrupo;
                    grupoWS.Nome = item.Nome;
                    grupoWS.Base64Imagem = Convert.ToBase64String(item.Imagem);
                    gruposWS.Add(grupoWS);
                }
            }

            return gruposWS;
        }

        [HttpGet]
        public List<TarefaWS> GetProximasTarefas(string token, int idUsuario, int idGrupo)
        {
            List<TarefaWS> tarefasWS = null;

            if (validarToken(token))
            {
                TarefaService tarefaService = new TarefaService();
                List<TAREFA> tarefas = tarefaService.ListarProximasTarefasDoUsuario(idUsuario, idGrupo);

                tarefasWS = converterParaTarefasWS(tarefas);
            }

            return tarefasWS;
        }

        [HttpGet]
        public List<ContatoWS> GetContatos(string token, int idUsuario, int idGrupo)
        {
            List<ContatoWS> contatosWS = null;
            if (validarToken(token))
            {
                ContatoService contatoService = new ContatoService();
                List<CONTATO> contatos = contatoService.Listar(idUsuario, idGrupo);

                contatosWS = converterParaContatosWS(contatos);
            }

            return contatosWS;
        }

        [HttpGet]
        public List<CompromissoWS> GetProximosCompromissos(string token, int idUsuario, int idGrupo)
        {
            List<CompromissoWS> compromissosWS = null;
            if (validarToken(token))
            {
                CompromissoService compromissoService = new CompromissoService();
                List<COMPROMISSO> compromissos = compromissoService.ListarProximosCompromissosDoUsuario(idUsuario, idGrupo);

                compromissosWS = converterParaCompromissosWS(compromissos, compromissoService.GetContext());
            }

            return compromissosWS;
        }

        
        // --------------------------------- Métodos Auxiliares ---------------------------------//

        private bool validarToken(string token)
        {
            return Tokens.TOKENS_ACEITOS.Contains(token, StringComparer.InvariantCultureIgnoreCase);
        }

        private List<CompromissoWS> converterParaCompromissosWS(List<COMPROMISSO> compromissos, OrganizadorPessoalContext context)
        {
            List<CompromissoWS> compromissosWS = null;
            if (compromissos != null)
            {
                compromissosWS = new List<CompromissoWS>();
                foreach (COMPROMISSO compromisso in compromissos)
                {
                    CompromissoWS compromissoWS = new CompromissoWS();
                    compromissoWS.IdCompromisso = compromisso.IdCompromisso;
                    
                    if (compromisso.IdProprietario.HasValue)
                    {
                        int idProprietario = compromisso.IdProprietario.Value;

                        compromissoWS.IdProprietario = idProprietario;
                        
                        UsuarioService usuarioService = new UsuarioService(context);
                        var usuario = usuarioService.BuscarPorId(idProprietario);

                        compromissoWS.NomeProprietario = usuario.Nome;
                    }

                    compromissoWS.IdGrupo = compromisso.IdGrupo.GetValueOrDefault(0);
                    compromissoWS.Titulo = compromisso.Titulo;
                    compromissoWS.DataInicio = compromisso.DataInicio.ToString(FORMATO_DATE_TIME);
                    compromissoWS.DataTermino = compromisso.DataTermino.ToString(FORMATO_DATE_TIME);
                    compromissoWS.Descricao = compromisso.Descricao;

                    List<ColaboradorWS> colaboradoresWS = new List<ColaboradorWS>();
                    foreach (var cc in compromisso.COMPROMISSO_CONTATOS)
                    {
                        if (cc.FlagAtivo.Equals("S"))
                        {
                            ColaboradorWS colaboradorWS = new ColaboradorWS();
                            colaboradorWS.IdCompromisso = compromisso.IdCompromisso;
                            colaboradorWS.IdContato = cc.IdContato;
                            colaboradorWS.IdColaborador = cc.IdColaborador.GetValueOrDefault(0);
                            colaboradorWS.IdGrupoColaborador = cc.IdGrupoColaborador.GetValueOrDefault(0);
                            colaboradorWS.NomeColaborador = cc.CONTATO.Nome;

                            String estado = "";
                            switch (cc.Estado)
                            {
                                case "A":
                                    estado = "Aceito";
                                    break;
                                case "P":
                                    estado = "Pendente";
                                    break;
                                case "R":
                                    estado = "Rejeitado";
                                    break;
                                default:
                                    break;
                            }
                            colaboradorWS.Estado = estado;

                            colaboradoresWS.Add(colaboradorWS);
                        }
                    }
                    compromissoWS.Colaboradores = colaboradoresWS;

                    compromissosWS.Add(compromissoWS);
                }
            }

            return compromissosWS;
        }

        private List<TarefaWS> converterParaTarefasWS(List<TAREFA> tarefas)
        {
            List<TarefaWS> tarefasWS = null;
            if (tarefas != null)
            {
                tarefasWS = new List<TarefaWS>();
                foreach (var tarefa in tarefas)
                {
                    TarefaWS tarefaWS = new TarefaWS();
                    tarefaWS.IdTarefa = tarefa.IdTarefa;
                    tarefaWS.IdProprietario = tarefa.IdProprietario.GetValueOrDefault(0);

                    if (tarefa.USUARIO_GRUPO != null)
                    {
                        tarefaWS.NomeProprietario = tarefa.USUARIO_GRUPO.USUARIO.Nome;
                    }

                    tarefaWS.IdExecutor = tarefa.IdExecutor.GetValueOrDefault(0);

                    if (tarefa.USUARIO_GRUPO1 != null)
                    {
                        tarefaWS.NomeExecutor = tarefa.USUARIO_GRUPO1.USUARIO.Nome;
                    }

                    tarefaWS.IdGrupoProprietario = tarefa.IdGrupoProprietario.GetValueOrDefault(0);
                    tarefaWS.IdGrupoExecutor = tarefa.IdGrupoExecutor.GetValueOrDefault(0);
                    tarefaWS.IdCompromisso = tarefa.IdCompromisso.GetValueOrDefault(0);
                    tarefaWS.Titulo = tarefa.Titulo;
                    tarefaWS.DataInicio = tarefa.DataInicio.ToString(FORMATO_DATE_TIME);

                    if (tarefa.DataTermino != null)
                    {
                        tarefaWS.DataTermino = tarefa.DataTermino.Value.ToString(FORMATO_DATE_TIME);
                    }

                    tarefaWS.Descricao = tarefa.Descricao;
                    tarefaWS.Observacao = tarefa.Observacao;

                    switch (tarefa.Estado)
                    {
                        case "A":
                            tarefaWS.Estado = "Aceita";
                            break;
                        case "C":
                            tarefaWS.Estado = "Concluída";
                            break;
                        case "R":
                            tarefaWS.Estado = "Rejeitada";
                            break;
                        case "P":
                            tarefaWS.Estado = "Pendente";
                            break;
                        default:
                            break;
                    }

                    tarefasWS.Add(tarefaWS);
                }
            }

            return tarefasWS;
        }

        private List<ContatoWS> converterParaContatosWS(List<CONTATO> contatos)
        {
            List<ContatoWS> contatosWS = null;

            if (contatos != null)
            {
                contatosWS = new List<ContatoWS>();

                foreach (var contato in contatos)
                {
                    ContatoWS contatoWS = new ContatoWS();
                    contatoWS.IdContato = contato.IdContato;
                    contatoWS.IdUsuarioProprietario = contato.IdUsuarioProprietario.GetValueOrDefault(0);
                    contatoWS.IdGrupoProprietario = contato.IdGrupoProprietario.GetValueOrDefault(0);
                    contatoWS.idUsuario = contato.IdUsuario.GetValueOrDefault(0);
                    contatoWS.Nome = contato.Nome;
                    contatoWS.Email = contato.Email;
                    contatoWS.Telefone = contato.Telefone;
                    contatoWS.Endereco = contato.Endereco;
                    
                    if (contato.USUARIO != null)
                    {
                        contatoWS.FotoB64 = Convert.ToBase64String(contato.USUARIO.Foto);
                    }

                    contatosWS.Add(contatoWS);
                }
            }

            return contatosWS;
        }
    }
}
