﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter]
    public class EventoController : Controller
    {
        TarefaService tarefaService;
        CompromissoService compromissoService;

        public EventoController()
        {
            tarefaService = new TarefaService();
            compromissoService = new CompromissoService();
        }

        public ActionResult Gerenciar()
        {
            var sessao = ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            int idProprietario = sessao.Usuario.IdUsuario;
            int idGrupo = sessao.Grupo.IdGrupo;
            
            EventoVM vm = new EventoVM(idProprietario, idGrupo, true);

            return View(vm);
        }

        public ActionResult MeusEventos()
        {
            var sessao = ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            int idExecutor = sessao.Usuario.IdUsuario;
            int idGrupo = sessao.Grupo.IdGrupo;

            EventoVM vm = new EventoVM(idExecutor, idGrupo, false);

            return View(vm);
        }

        public ActionResult BuscarEventos()
        {
            EventoVM vm = new EventoVM();
            return View(vm);
        }

        [HttpPost]
        public ActionResult BuscarEventos(EventoVM vm)
        {
            DateTime data;
            try
            {
                data = DateTime.Parse(vm.Data);

                if (ModelState.IsValid)
                {
                    var sessao = ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
                    int idExecutor = sessao.Usuario.IdUsuario;
                    int idGrupo = sessao.Grupo.IdGrupo;

                    vm.ListaTarefa = tarefaService.ListarTarefasPorData(idExecutor, idGrupo, data);
                    // Listar Compromissos

                    return View(vm);
                }
            }
            catch (Exception)
            {
                List<ValidationResult> erro = new List<ValidationResult>();
                erro.Add(new ValidationResult("dataInvalida", "Selecione uma data"));
                ModelState.AddModelErrors(erro);
            }

            return View();
        }

        public ActionResult PesquisarEventos()
        {
            return View();
        }

        [HttpPost]
        public ActionResult PesquisarEventos(string DataBusca)
        {
            var sessao = ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            int idUsuario = sessao.Usuario.IdUsuario;
            int idGrupo = sessao.Grupo.IdGrupo;
            
            //List<Evento> eventos = new List<Evento>();
            List<TAREFA> tarefas = new List<TAREFA>();
            List<COMPROMISSO> compromissos = new List<COMPROMISSO>();

            if (IsDate(DataBusca))
            {
                DateTime data = DateTime.Parse(DataBusca);
                tarefas = tarefaService.ListarTarefasAceitasDoDia(idUsuario, idGrupo, data);
                compromissos = compromissoService.ListarCompromissosAceitosDoDia(idUsuario, idGrupo, data);

                /*
                foreach (var t in tarefas)
                {
                    eventos.Add(ConverterTarefa(t));
                }
                foreach (var c in compromissos)
                {
                    eventos.Add(ConverterCompromisso(c));
                }
                */

            }

            EventoBuscarVM vm = new EventoBuscarVM();
            //vm.Eventos = eventos.OrderBy(d=>d.DataInicio).ToList();
            EventoFacade facade = new EventoFacade(tarefas, compromissos);
            vm.Eventos = facade.OrdenarEventos();

            return View(vm);
        }


        // --------------
        // Método auxiliar
        private bool IsDate(string data)
        {
            try
            {
                DateTime.Parse(data);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }


        // Métodos auxiliares -------------------
        public Evento ConverterTarefa(TAREFA tarefa)
        {
            Evento evento = new Evento();
            evento.Tipo = "T";
            evento.Id = tarefa.IdTarefa;
            evento.DataInicio = tarefa.DataInicio;
            evento.DataTermino = tarefa.DataTermino;
            evento.Titulo = tarefa.Titulo;

            return evento;
        }

        public Evento ConverterCompromisso(COMPROMISSO compromisso)
        {
            Evento evento = new Evento();
            evento.Tipo = "C";
            evento.Id = compromisso.IdCompromisso;
            evento.DataInicio = compromisso.DataInicio;
            evento.DataTermino = compromisso.DataTermino;
            evento.Titulo = compromisso.Titulo;

            return evento;
        }
    }

    public class Evento
    {
        public string Tipo { get; set; }
        public int Id { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime? DataTermino { get; set; }
        public string Titulo { get; set; }

    }
}
