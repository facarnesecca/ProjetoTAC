﻿using OrganizadorPessoal.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrganizadorPessoal.Controllers
{
    public static class ControllerExtensions
    {
        /**
         *  Técnica de Extension Method.
         *  http://csharpbrasil.com.br/csharp/extension-methods/
         *  A ideia é estender as funcionalidades de ModelStateDictionary sem precisar criar uma herança.
         *  A vantagem é poder usar a mesma classe 
         *  ModelStateDictionary sem precisar alterar as configurações nativas do controller.
         */
        public static void AddModelErrors(this ModelStateDictionary modelState, List<ValidationResult> erros)
        {
            if (erros != null)
            {
                foreach (var item in erros)
                {
                    modelState.AddModelError(item.Nome, item.Mensagem);
                }
            }
        }
    }
}