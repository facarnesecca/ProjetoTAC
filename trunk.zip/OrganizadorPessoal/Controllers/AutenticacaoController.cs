﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.AutenticacaoVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrganizadorPessoal.Controllers
{
    public class AutenticacaoController : Controller
    {
       
        
        public ActionResult Logar()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Logar(AutenticacaoLogarVM vm)
        {
            if (ModelState.IsValid)
            {
                string email = vm.Email;
                string senha = vm.Senha;

                UsuarioService usuarioService = new UsuarioService();
                var erros = usuarioService.ValidarAutenticacao(email, senha);

                if (erros.Count == 0)
                {
                    var usuario = usuarioService.Autenticar(email, senha);
                    
                    SessaoUsuarioModel sessaoUsuario = new SessaoUsuarioModel();
                    sessaoUsuario.Usuario = usuario;
                    sessaoUsuario.QtdGruposUsuario = usuario.USUARIO_GRUPO.Count;

                    if (usuario.AdmSistema.Equals("S"))
                    {
                        // Redireciona para a Home caso o usuário seja um adm do sistema

                        Session[SessaoUsuarioModel.KEY_IDENTIFICADOR] = sessaoUsuario;

                        return RedirectToAction("Index", "Home");
                    }


                    int idUsuario = usuario.IdUsuario;
                    int qntGruposDoUsuario = usuarioService.QuantidadeGruposDoUsuario(idUsuario);
                    if (qntGruposDoUsuario == 1)
                    {
                        // Redireciona para a Home caso o usuário esteja associado só a 1 grupo ou se ele for adm do sistema

                        var grupo = usuarioService.BuscarGrupoDoUsuario(idUsuario);
                        sessaoUsuario.Grupo = grupo;

                        int idGrupo = grupo.IdGrupo;
                        sessaoUsuario.PodeConvidarParaGrupo =
                            usuarioService.PodeConvidarNovosMembrosParaOGrupo(idUsuario, idGrupo);

                        Session[SessaoUsuarioModel.KEY_IDENTIFICADOR] = sessaoUsuario;

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        // Se o usuário estiver associado a mais de um grupo, 
                        // então redireciona para a tela de escolha do grupo

                        Session[SessaoUsuarioModel.KEY_IDENTIFICADOR] = sessaoUsuario;

                        return RedirectToAction("EscolherGrupo");
                    }

                }
                else
                {
                    ModelState.AddModelErrors(erros);
                }

            }


            return View(vm);
        }

        
        public ActionResult EscolherGrupo()
        {
            SessaoUsuarioModel sessaoUsuario = ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            if (sessaoUsuario == null)
            {
                return RedirectToAction("Logar");
            }

            UsuarioService usuarioService = new UsuarioService();
            
            int idUsuarioNaSessao = sessaoUsuario.Usuario.IdUsuario;
            var gruposDoUsuario = usuarioService.ListarGruposAtivosDoUsuario(idUsuarioNaSessao);

            AutenticacaoEscolherGrupoVM vm = new AutenticacaoEscolherGrupoVM();
            vm.Grupos = gruposDoUsuario;

            return View(vm);
        }

        
        [HttpPost]
        public ActionResult EscolherGrupo(AutenticacaoEscolherGrupoVM vm)
        {
            int idGrupoSelecionado = Int32.Parse(vm.IdGrupoSelecionado);

            GrupoService grupoService = new GrupoService();
            UsuarioService usuarioService = 
                new UsuarioService(grupoService.GetContext());

            var grupoSelecionado = grupoService.BuscarPorId(idGrupoSelecionado);

            // Atribui o grupo selecionado na sessao do usuário

            SessaoUsuarioModel sessaoUsuario = (SessaoUsuarioModel) Session[SessaoUsuarioModel.KEY_IDENTIFICADOR];
            int idUsuario = sessaoUsuario.Usuario.IdUsuario;

            sessaoUsuario.Grupo = grupoSelecionado;
            sessaoUsuario.PodeConvidarParaGrupo =
                usuarioService.PodeConvidarNovosMembrosParaOGrupo(idUsuario, idGrupoSelecionado);

            Session[SessaoUsuarioModel.KEY_IDENTIFICADOR] = sessaoUsuario;

            return RedirectToAction("Index", "Home");
        }

        
        public ActionResult Sair()
        {
            Session.Abandon();
            return RedirectToAction("Logar");
        }


    }
}
