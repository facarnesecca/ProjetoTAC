﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter]
    public class HomeController : Controller
    {
        
        public ActionResult Index()
        {
            var sessaoUsuario =
                   ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            CalendarioVM vm = new CalendarioVM();
            ViewBag.Grupo = ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]).Grupo.Nome;

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;

            CompromissoService compromissoService = new CompromissoService();
            int compromissos = compromissoService.ListarCompromissosPendentes(idUsuario, idGrupo).Count;
            ViewBag.CompromissosPendentes = compromissos;

            TarefaService tarefaService = new TarefaService();
            int tarefas = tarefaService.ListarTarefasPendentes(idUsuario, idGrupo).Count;
            ViewBag.TarefasPendentes = tarefas;

            ViewBag.Pendencias = tarefas > 0 || compromissos > 0;
            ViewBag.Mensagem = ExibeMensagemHtml(tarefas, compromissos);

            return View(vm);
        }

        public PartialViewResult _Calendario(CalendarioVM model)
        {
            return PartialView(model);
        }

        public PartialViewResult _Feedback()
        {
            // busca a situação das últimas 2 tarefas atualizadas


            return PartialView();
        }
        
        [HttpPost]
        public PartialViewResult _Calendario(string ano, string mes, string dia)
        {
            if (ano != null && mes != null && dia != null)
            {
                return PartialView(
                    new CalendarioVM(int.Parse(ano), int.Parse(mes), int.Parse(dia)));
            }
            else
            {
                return PartialView(
                    new CalendarioVM());
            }
        }

        private string ExibeMensagemHtml(int tarefas, int compromissos)
        {
            string mensagem = "";

            bool pendencias = tarefas > 0 || compromissos > 0;
            if (pendencias)
            {
                mensagem += "Você possui ";
    
                int t = tarefas;
                int c = compromissos;

                if (t == 1)
                {
                    mensagem += "<a href='/Tarefa/Index'>" + t + " Tarefa " + "</a>";

                }
                else if (t > 1)
                {
                    mensagem += "<a href='/Tarefa/Index'>" + t + " Tarefas " + "</a>";
                }
                if (t > 0 && c > 0)
                {
                    mensagem += " e ";
                }
                if (c == 1)
                {
                    mensagem += "<a href='/Compromisso/Index'>" + c + " Compromisso " + "</a>";
                }
                else if (c > 0)
                {
                    mensagem += "<a href='/Compromisso/Index'>" + c + " Compromissos " + "</a>";
                }
                if (t + c == 1)
	            {
		             mensagem += " pendente";
	            }
                else if (t + c > 1)
	            {
		             mensagem += " pendentes";
	            }
    
            }


            return mensagem;
        }
    }
}
