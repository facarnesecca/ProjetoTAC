﻿using OrganizadorPessoal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Controllers
{
    public class SessaoUsuarioModel
    {
        public const string KEY_IDENTIFICADOR = "SESSAO_USUARIO_MODEL";
        
        public USUARIO Usuario { get; set; }
        
        // Grupo que o usuário está autenticado
        public GRUPO Grupo { get; set; }

        public int QtdGruposUsuario { get; set; }

        // Indica se pode convidar novos membros para o grupo 
        public bool PodeConvidarParaGrupo { get; set; }

    }
}