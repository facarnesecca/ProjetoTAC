﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.UsuarioVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter("T")]
    public class UsuarioController : Controller
    {

        [PermitirAnonimos]
        public ActionResult Registrar(string email)
        {
            UsuarioService usuarioService = new UsuarioService();
            var usuarioEncontrado = usuarioService.BuscarPorEmail(email);
            
            if (usuarioEncontrado != null && usuarioEncontrado.FlagAtivo.Equals("N"))
            {
                UsuarioRegistrarVM vm = new UsuarioRegistrarVM();
                vm.Email = usuarioEncontrado.Email;

                return View(vm);
            }

            return RedirectToAction("ErroRegistro", new { email = email });
        }


        [PermitirAnonimos]
        [HttpPost]
        public ActionResult Registrar(UsuarioRegistrarVM vm)
        {
            if (ModelState.IsValid)
            {
                UsuarioService usuarioService = new UsuarioService();
                
                string email = vm.Email;
                string nome = vm.Nome;
                string telefone = vm.Telefone;
                if (telefone != null)
                    telefone = telefone.Replace("(", "").Replace(")", "").Replace(" ", "");
                string endereco = vm.Endereco;
                string senha = vm.Senha;

                // Foto do usuário
                string fotoUsuarioBase64 = vm.FotoUsuarioBase64;
                byte[] bytesFoto = null;
                if (fotoUsuarioBase64 != null)
                {
                    bytesFoto = Convert.FromBase64String(fotoUsuarioBase64);
                }

                // Realiza o registro
                USUARIO usuario = usuarioService.Registrar(email, nome, telefone, endereco, senha, bytesFoto);
                int idUsuario = usuario.IdUsuario;

                // Configura a sessão com o usuário

                var grupo = usuarioService.BuscarGrupoDoUsuario(idUsuario);
                int idGrupo = grupo.IdGrupo;

                SessaoUsuarioModel sessaoUsuario = new SessaoUsuarioModel();                
                sessaoUsuario.Usuario = usuario;
                sessaoUsuario.QtdGruposUsuario = usuario.USUARIO_GRUPO.Count;
                sessaoUsuario.Grupo = grupo;
                sessaoUsuario.PodeConvidarParaGrupo =
                    usuarioService.PodeConvidarNovosMembrosParaOGrupo(idUsuario, idGrupo);

                Session[SessaoUsuarioModel.KEY_IDENTIFICADOR] = sessaoUsuario;

                return RedirectToAction("Index", "Home");
            }

            return View(vm);

        }


        public ActionResult Editar()
        {
            var usuarioSessao = 
                ((SessaoUsuarioModel) Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]).Usuario;

            UsuarioEditarVM vm = new UsuarioEditarVM();
            vm.IdUsuario = usuarioSessao.IdUsuario;
            vm.Nome = usuarioSessao.Nome;
            vm.Telefone = usuarioSessao.Telefone;
            vm.Endereco = usuarioSessao.Endereco;

            if (usuarioSessao.Foto != null)
                vm.FotoUsuarioBase64 = Convert.ToBase64String(usuarioSessao.Foto);


            return View(vm);
        }


        [HttpPost]
        public ActionResult Editar(UsuarioEditarVM vm)
        {
            if (ModelState.IsValid)
            {
                UsuarioService usuarioService = new UsuarioService();

                bool senhaInformadaCorresponde = usuarioService.ValidarSenha(vm.IdUsuario, vm.Senha);
                if (!senhaInformadaCorresponde)
                {
                    ModelState.AddModelError(String.Empty, "A senha informada não corresponde a senha do usuário");
                    return View(vm);
                }

                int idUsuario = vm.IdUsuario;
                string nome = vm.Nome;
                string telefone = vm.Telefone;
                if (telefone != null)
                    telefone = telefone.Replace("(", "").Replace(")", "").Replace(" ", "");
                string endereco = vm.Endereco;
                string senha = vm.SenhaNova;

                // Foto do usuário
                string fotoUsuarioBase64 = vm.FotoUsuarioBase64;
                byte[] bytesFoto = null;
                if (fotoUsuarioBase64 != null)
                {
                    bytesFoto = Convert.FromBase64String(fotoUsuarioBase64);
                }

                // Atualiza o registro no banco
                var usuarioAlterado = usuarioService.Atualizar(idUsuario, nome, senha, telefone, endereco, bytesFoto);

                // Atualiza a sessão
                SessaoUsuarioModel sessaoUsuario = 
                    (SessaoUsuarioModel) Session[SessaoUsuarioModel.KEY_IDENTIFICADOR];
                sessaoUsuario.Usuario = usuarioAlterado;
                
                return RedirectToAction("Index", "Home");
            }

            return View(vm);
        }

        [PermitirAnonimos]
        public ActionResult ErroRegistro(string email)
        {
            ViewBag.Email = email;
            return View();
        }

        public ActionResult QRCode()
        {
            var usuarioSessao =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]).Usuario;

            var token = Crypto.Encrypt(usuarioSessao.Email + ";" + usuarioSessao.Senha);
            var teste = Crypto.Decrypt(token);

            ViewBag.token = token;

            return View();
        }
    }
}
