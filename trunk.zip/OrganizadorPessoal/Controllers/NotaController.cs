﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.NotaVM;
using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.ViewModels;

namespace OrganizadorPessoal.Controllers
{
    public class NotaController : Controller
    {
        //
        // GET: /Nota/
        
        public ActionResult Index()
        {
            NotaService notaService = new NotaService();
            NotaIndexVM vm = new NotaIndexVM();

            vm.Registros = notaService.ListarPorCompromisso(5); // TODO receeber parametro de compromisso

            return View(vm);
        }

        public ActionResult Cadastrar()
        {
            return View(new NotaCadastrarVM());
        }

        [HttpPost]
        public ActionResult Cadastrar(NotaCadastrarVM vm)
        {
            if (ModelState.IsValid)
            {
                var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

                NOTA nota = new NOTA();
                nota.Descricao = vm.Descricao;
                nota.IdUsuario = sessaoUsuario.Usuario.IdUsuario;
                nota.IdGrupo = sessaoUsuario.Grupo.IdGrupo;
                nota.FlagAtivo = "S";
                nota.IdCompromisso = 5; // TODO receeber parametro de compromisso

                NotaService notaService = new NotaService();
                notaService.Adicionar(nota);

                return RedirectToAction("Index");
            }

            return View(vm);
        }

        [HttpPost]
        public ActionResult Desativar(int id)
        {
            NotaService notaService = new NotaService();
            notaService.Remover(id);
            //return RedirectToAction("Index");
            return Json(new { success = true });

        }

    }
}
