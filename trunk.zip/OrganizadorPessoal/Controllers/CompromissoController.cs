﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OrganizadorPessoal.Controllers
{
    [AutenticacaoFilter]
    public class CompromissoController : Controller
    {
        CompromissoService compromissoService;
        NotaService notaService;

        public CompromissoController()
        {
            compromissoService = new CompromissoService();
            notaService = new NotaService();
        }

        public ActionResult Index()
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;
            var compromissosUsuario = compromissoService.ListarCompromissosPendentes(idUsuario, idGrupo);

            CompromissoIndexVM vm = new CompromissoIndexVM();
            vm.ListaCompromissos = compromissosUsuario;
            vm.GerenciarCompromisso = false;

            return View(vm);
        }

        [HttpPost]
        public ActionResult Index(CompromissoIndexVM vm)
        {
            var sessaoUsuario =
                ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;

            if (vm.GerenciarCompromisso)
                vm.ListaCompromissos = compromissoService.ListarCompromissosProprietario(idUsuario, idGrupo);
            else
                vm.ListaCompromissos = compromissoService.ListarCompromissosPendentes(idUsuario, idGrupo);

            return View(vm);
        }

        public ActionResult Cadastrar(string dia)
        {
            CompromissoCadastrarVM vm = CompromissoCadastrarVM.ConstruirFormParaNovo();
            Session["colaboradores"] = null;

            if (dia != null)
                vm.DataHoraInicio = dia;
            else
                vm.DataHoraInicio = DateTime.Now.Date.ToShortDateString();

            return View(vm);
        }


        // cmps = id do compromisso
        // ctt = id do contato
        // ta = tipo da ação: A (Aceitar) ou R (Rejeitar)
        [PermitirAnonimos]
        public ActionResult Convite(int cpms, int ctt, string ta) 
        {   
            bool sucesso = false;

            CompromissoService cService = new CompromissoService();

            switch (ta.ToUpper())
	        {
		        case "A":
                    sucesso = cService.AceitarCompromisso(cpms, ctt);
                    break;
                case "R":
                    sucesso = cService.RejeitarCompromisso(cpms, ctt);
                    break;
                default:
                    break;
	        }

            ViewBag.Sucesso = sucesso;
            return View();
        }

        [HttpPost]
        public ActionResult Cadastrar(CompromissoCadastrarVM vm)
        {
            if (ModelState.IsValid)
            {
                COMPROMISSO compromisso = CompromissoCadastrarVM.ConverterCompromissoVM(vm);
                List<CONTATO> colaboradores = new List<CONTATO>();

                // Verifica se foi adicionado algum colaborador
                if (Session["colaboradores"] != null)
                {
                    var idsColaboradores = Session["colaboradores"] as List<int>;
                    ContatoService contatoService = new ContatoService();

                    foreach (var idColaborador in idsColaboradores)
                    {
                        CONTATO colaborador = contatoService.Detalhes(idColaborador);
                        colaboradores.Add(colaborador);
                    }
                }

                List<ValidationResult> erros = compromissoService.ValidarAdicionarCompromisso(compromisso);
                if (erros.Count == 0)
                {
                    var sessao = (SessaoUsuarioModel) Session[SessaoUsuarioModel.KEY_IDENTIFICADOR];

                    string nomeUsuarioProprietario = sessao.Usuario.Nome;
                    string nomeGrupoProprietario = sessao.Grupo.Nome;

                    compromissoService.Adicionar(compromisso, colaboradores, nomeUsuarioProprietario, nomeGrupoProprietario);

                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelErrors(erros);
                }
            }

            Session["colaboradores"] = null;

            CompromissoCadastrarVM.PopularItens(vm);
            return View(vm);
        }

        [HttpPost]
        public ActionResult Consultar(int id)
        {
            var sessaoUsuario =
                   ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;
            ViewBag.IdUsuarioSessao = idUsuario.ToString();
            
            COMPROMISSO registro = compromissoService.BuscarPorId(id);
            CompromissoCadastrarVM vm = CompromissoCadastrarVM.ConverterCompromissoVM(registro);

            // se o usuário em sessão não for o proprietário, armazena seu estado neste compromisso
            ViewBag.Estado = "";
            if (registro.IdProprietario != idUsuario)
                ViewBag.Estado = compromissoService.InformaEstadoCompromisso(registro.IdCompromisso, idUsuario);

            vm.Notas = notaService.ListarPorCompromisso(id).OrderByDescending(n => n.IdNota).ToList();


            return View(vm);
        }

        public ActionResult Atualizar(int id)
        {
            Session["colaboradores"] = null;
            COMPROMISSO compromisso = compromissoService.BuscarPorId(id);
            CompromissoCadastrarVM vm = CompromissoCadastrarVM.ConverterCompromissoVM(compromisso);
            vm.DataHoraInicio = vm.DataHoraInicioDateTime.ToString();
            vm.DataHoraTermino = vm.DataHoraTerminoDateTime.ToString();

            CompromissoCadastrarVM.PopularItens(vm);

            foreach (var colaborador in vm.CompromissosContatos)
            {
                AdicionaColaborador(colaborador.IdContato);
                
            }

            return View(vm);
        }

        [HttpPost]
        public ActionResult Atualizar(CompromissoCadastrarVM vm)
        {
            if (ModelState.IsValid)
            {
                COMPROMISSO compromisso = CompromissoCadastrarVM.ConverterCompromissoVM(vm);
                List<CONTATO> colaboradores = new List<CONTATO>();

                // Verifica se foi adicionado algum colaborador
                if (Session["colaboradores"] != null)
                {
                    var idsColaboradores = Session["colaboradores"] as List<int>;
                    ContatoService contatoService = new ContatoService();

                    // Adiciona os colaboradores da sessão na lista
                    foreach (var idColaborador in idsColaboradores)
                    {
                        CONTATO colaborador = contatoService.Detalhes(idColaborador);
                        colaboradores.Add(colaborador);
                    }
                }

                List<ValidationResult> erros = compromissoService.ValidarAdicionarCompromisso(compromisso);
                if (erros.Count == 0)
                {
                    var sessao = (SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR];

                    string nomeUsuarioProprietario = sessao.Usuario.Nome;
                    string nomeGrupoProprietario = sessao.Grupo.Nome;

                    compromissoService.Atualizar(compromisso, colaboradores, nomeUsuarioProprietario, nomeGrupoProprietario);
                    Session["colaboradores"] = null;

                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelErrors(erros);
                }
            }


            CompromissoCadastrarVM.PopularItens(vm);
            return View(vm);
        }

        public ActionResult Remover(int id)
        {

            compromissoService.Desativar(id);

            return RedirectToAction("Index", "Home");
        }


        [HttpPost]
        public PartialViewResult _NotasCompromisso(int idCompromisso, string texto)
        {
            var sessaoUsuario =
                   ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idUsuario = sessaoUsuario.Usuario.IdUsuario;
            int idGrupo = sessaoUsuario.Grupo.IdGrupo;
            ViewBag.IdUsuarioSessao = idUsuario.ToString();

            NotaService notaService = new NotaService();

            if (texto != "")
            {
                NOTA nota = new NOTA();
                nota.Descricao = texto;
                nota.IdUsuario = sessaoUsuario.Usuario.IdUsuario;
                nota.IdGrupo = sessaoUsuario.Grupo.IdGrupo;
                nota.FlagAtivo = "S";
                nota.IdCompromisso = idCompromisso;

                List<ValidationResult> erros = notaService.ValidaAdicionar(nota);
                if (erros.Count.Equals(0))
                    notaService.Adicionar(nota); 
                else
                    ModelState.AddModelErrors(erros);
            }
            
            COMPROMISSO registro = compromissoService.BuscarPorId(idCompromisso);
            CompromissoCadastrarVM vm = CompromissoCadastrarVM.ConverterCompromissoVM(registro);

            vm.Notas = notaService.ListarPorCompromisso(idCompromisso).OrderByDescending(n => n.IdNota).ToList();


            return PartialView("_NotasCompromisso", vm);
        }

        public ActionResult AtualizaEstado(int id, string estado)
        {
            var sessaoUsuario =
                   ((SessaoUsuarioModel)Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            int idUsuario = sessaoUsuario.Usuario.IdUsuario;

            // Atualiza o estado
            COMPROMISSO_CONTATOS compromissoContato = compromissoService.AtualizarEstado(id, idUsuario, estado);
            ViewBag.Estado = compromissoContato.Estado;
            
            // Busca o compromisso
            COMPROMISSO compromisso = compromissoService.BuscarPorId(id);
            CompromissoCadastrarVM vm = CompromissoCadastrarVM.ConverterCompromissoVM(compromisso);

            vm.Notas = notaService.ListarPorCompromisso(id).OrderByDescending(n => n.IdNota).ToList();

            return View("Consultar", vm);
        }

        // Função que coloca (ou remove) os ids dos colaboradores selecionados na sessão
        [HttpPost]
        public ActionResult AtualizaColaborador(string idColaborador, string adiciona)
        {
            int id = int.Parse(idColaborador);
            bool condicao = bool.Parse(adiciona);

            // Adiciona
            if (condicao)
                AdicionaColaborador(id);
            else // Remove
                RemoveColaborador(id);
            
            return Json(new { success = true });
        }

        // Função auxiliar que adiciona o colaborador na sessão
        private void AdicionaColaborador(int id)
        {
            if (Session["colaboradores"] != null)
            {
                ((List<int>)Session["colaboradores"]).Add(id);
            }
            else
            {
                Session["colaboradores"] = new List<int>() { id };
            }
        }

        // Função auxiliar que remove o colaborador da sessão
        private void RemoveColaborador(int id)
        {
            if (Session["colaboradores"] != null)
            {
                ((List<int>)Session["colaboradores"]).Remove(id);
            }
        }
    }
}
