﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models
{
    public class EmailModelos
    {
        public const string DOMINIO_SITE_DESENVOLVIMENTO = "http://localhost:49250/";
        public const string DOMINIO_SITE_PRODUCAO        = "http://organizador.fernandogalloro.com.br/";


        public const string CAMINHO_VIRTUAL_HTML_ATRIBUICAO_TAREFA = "~/Content/ModelosEmails/email_atribuicao_tarefa.html";
        public const string CAMINHO_VIRTUAL_HTML_CONVITE_GRUPO = "~/Content/ModelosEmails/email_convite_grupo.html";
        public const string CAMINHO_VIRTUAL_HTML_CONVITE_COMPROMISSO = "~/Content/ModelosEmails/email_convite_compromisso.html";

        public static String GerarMensagemAtribuicaoTarefa(string nomeProprietarioTarefa, 
            string nomeReceptorTarefa, string nomeGrupo, string tituloTarefa, string dateTimeTarefa, string descricaoTarefa)
        {
            string caminhoFisicoArquivo =
                HttpContext.Current.Server.MapPath(CAMINHO_VIRTUAL_HTML_ATRIBUICAO_TAREFA);

            string conteudoHtml = File.ReadAllText(caminhoFisicoArquivo);

            conteudoHtml = conteudoHtml.Replace("[nome]", nomeReceptorTarefa)
                                        .Replace("[nome do dono da tarefa]", nomeProprietarioTarefa)
                                        .Replace("[nome do grupo]", nomeGrupo)
                                        .Replace("[Título da tarefa]", tituloTarefa)
                                        .Replace("[Data e hora da tarefa]", dateTimeTarefa)
                                        .Replace("[Descrição da tarefa]", descricaoTarefa);

            return conteudoHtml;
        }

        public static String GerarMensagemConviteGrupo(string nomeGrupo, string emailDoUsuario)
        {
            string caminhoFisicoArquivo =
                HttpContext.Current.Server.MapPath(CAMINHO_VIRTUAL_HTML_CONVITE_GRUPO);

            string conteudoHtml = File.ReadAllText(caminhoFisicoArquivo);

            string link = "";
            if (HttpContext.Current.IsDebuggingEnabled)
            {
                link = DOMINIO_SITE_DESENVOLVIMENTO;
            }
            else
            {
                link = DOMINIO_SITE_PRODUCAO;
            }

            link += "usuario/registrar?email=" + emailDoUsuario;

            conteudoHtml = conteudoHtml.Replace("[nome do grupo]", nomeGrupo)
                                        .Replace("[link] aqui [/link]", "<a href='" + link + "'>aqui</a>")
                                        .Replace("[link]", link);
                                        

            return conteudoHtml;
        }


        public static String GerarMensagemConviteCompromisso(string nomeConvidado, string nomeProprietarioCompromisso, 
            string nomeGrupo, string tituloCompromisso, string dataHoraCompromisso, string descricaoCompromisso, int idCompromisso, int idContato)
        {
            string caminhoFisicoArquivo =
                HttpContext.Current.Server.MapPath(CAMINHO_VIRTUAL_HTML_CONVITE_COMPROMISSO);

            string conteudoHtml = File.ReadAllText(caminhoFisicoArquivo);

            string linkAceitar = "";
            string linkRejeitar = "";
            if (HttpContext.Current.IsDebuggingEnabled)
            {
                linkAceitar = DOMINIO_SITE_DESENVOLVIMENTO;
                linkRejeitar = DOMINIO_SITE_DESENVOLVIMENTO;
            }
            else
            {
                linkAceitar = DOMINIO_SITE_PRODUCAO;
                linkRejeitar = DOMINIO_SITE_PRODUCAO;
            }

            linkAceitar += "compromisso/convite?cpms=" + idCompromisso + "&ctt=" + idContato + "&ta=" + "a";
            linkRejeitar += "compromisso/convite?cpms=" + idCompromisso + "&ctt=" + idContato + "&ta=" + "r";

            conteudoHtml = conteudoHtml.Replace("[nome]", nomeConvidado)
                                        .Replace("[nome do dono do compromisso]", nomeProprietarioCompromisso)
                                        .Replace("[nome do grupo]", nomeGrupo)
                                        .Replace("[Título do compromisso]", tituloCompromisso)
                                        .Replace("[Data e hora do compromisso]", dataHoraCompromisso)
                                        .Replace("[Descrição do compromisso]", descricaoCompromisso)
                                        .Replace("[link_aceitar]", linkAceitar)
                                        .Replace("[link_rejeitar]", linkRejeitar);


            return conteudoHtml;
        }
    }
}