﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    /**
     * TODO A ideia é no futuro puxar os tokens do banco de dados
     * */
    public class Tokens
    {
        public static String[] TOKENS_ACEITOS = { "mob/fjem=1991sorgPeSSOalMob12366/",
                                                  "xxx=11112sORGPessoalMob1x3x",
                                                  "11112sORGPessoalMob1x322242"         };


    }
}