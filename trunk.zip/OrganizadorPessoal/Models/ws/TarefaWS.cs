﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    public class TarefaWS
    {
        public int IdTarefa { get; set; }
        public int IdProprietario { get; set; }
        public string NomeProprietario { get; set; }
        public int IdExecutor { get; set; }
        public string NomeExecutor { get; set; }
        public int IdGrupoProprietario { get; set; }
        public int IdGrupoExecutor { get; set; }
        public int IdCompromisso { get; set; }
        public string Titulo { get; set; }
        public string DataInicio { get; set; }
        public string DataTermino { get; set; }
        public string Descricao { get; set; }
        public string Observacao { get; set; }
        public string Estado { get; set; }
    }
}