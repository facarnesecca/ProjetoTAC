﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    public class ContatoWS
    {
        public int IdContato { get; set; }
        public int IdUsuarioProprietario { get; set; }
        public int IdGrupoProprietario { get; set; }
        public int idUsuario { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Endereco { get; set; }
        public string FotoB64 { get; set; }
    }
}