﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    public class UsuarioWS
    {
        public int IdUsuario { get; set; }
        public string Email { get; set; }
        public string Nome { get; set; }
    }
}