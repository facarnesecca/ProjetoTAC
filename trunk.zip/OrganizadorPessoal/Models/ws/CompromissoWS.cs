﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    public class CompromissoWS
    {
        public int IdCompromisso { get; set; }
        public int IdProprietario { get; set; }
        public string NomeProprietario { get; set; }
        public int IdGrupo { get; set; }
        public string Titulo { get; set; }
        public string DataInicio { get; set; }
        public string DataTermino { get; set; }
        public string Descricao { get; set; }

        public List<ColaboradorWS> Colaboradores { get; set; }
    }
}