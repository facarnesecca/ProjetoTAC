﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    public class ColaboradorWS
    {
        public int IdCompromisso { get; set; }
        public int IdContato { get; set; }
        public int IdColaborador { get; set; }
        public int IdGrupoColaborador { get; set; }
        public string NomeColaborador { get; set; }
        public string Estado { get; set; }
    }
}