﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.ws
{
    public class GrupoWS
    {
        public int IdGrupo { get; set; }
        public string Nome { get; set; }
        public string Base64Imagem { get; set; }
    }
}