﻿using OrganizadorPessoal.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.Services
{
    public class ContatoService
    {
        private OrganizadorPessoalContext context; 

        public ContatoService()
        {
            context = new OrganizadorPessoalContext();
        }

        public ContatoService(OrganizadorPessoalContext context)
        {
            this.context = context;
        }

        public List<CONTATO> Listar(int idusuario, int idgrupo)
        {
            return context.CONTATO.Where(c => c.IdUsuarioProprietario.Value.Equals(idusuario) && c.IdGrupoProprietario.Value.Equals(idgrupo) && c.FlagAtivo.Equals("S")).ToList();
        }

        public List<CONTATO> ListarContatosUsuarios(int idUsuario, int idGrupo)
        {
            var contatos = context.CONTATO.Where(c => c.IdUsuarioProprietario.Value.Equals(idUsuario) &&
                                                    c.IdGrupoProprietario.Value.Equals(idGrupo) &&
                                                    c.IdUsuario != null && c.FlagAtivo.Equals("S"));

            return contatos.ToList();
        }

        public void Remover(int id)
        {
            var contato = context.CONTATO.Find(id);
            contato.FlagAtivo = "N";

            // Remover a participação do contato de todos os compromissos criados pelo usuário que o removeu
            CompromissoService compromissoService = new CompromissoService();
            compromissoService.RemoverParticipanteDeMeusCompromissos(id);

            context.SaveChanges();
        }

        public CONTATO Detalhes(int id)
        {
            return context.CONTATO.Find(id);
        }

        public USUARIO_GRUPO UsuarioDoGrupo(string email, int idGrupo)
        {
            var usuarioEncontrado = context.USUARIO.FirstOrDefault(u => u.Email.Equals(email));
            var pertenceAoGrupo = usuarioEncontrado != null ? context.USUARIO_GRUPO.FirstOrDefault(ug=>ug.IdGrupo == idGrupo &&
                                                                        ug.IdUsuario == usuarioEncontrado.IdUsuario && 
                                                                        ug.FlagAtivo.Equals("S")) 
                                                                        : null;
            return pertenceAoGrupo;
        }

        public void Adicionar(CONTATO contato, bool convidarParaGrupo, bool permitirConvidarMembros)
        {
            int idUsuarioProprietario = contato.IdUsuarioProprietario.Value;
            int idGrupoProprietario = contato.IdGrupoProprietario.Value;
            string nomeGrupoProprietario = context.GRUPO.Find(idGrupoProprietario).Nome;


            string emailInformado = contato.Email;

            var transacao = context.Database.BeginTransaction();
            try
            {
                var contatoAdicionado = context.CONTATO.Add(contato);

                if (convidarParaGrupo)
                {
                    var usuarioEncontrado = context.USUARIO.FirstOrDefault(u => u.Email.Equals(emailInformado));
                    if (usuarioEncontrado == null) // Convida um contato para fazer parte do sistema
                    {
                        USUARIO usuario = new USUARIO();
                        usuario.Email = emailInformado;
                        usuario.FlagAtivo = "N";
                        usuario.AdmSistema = "N";
                        var usuarioAdicionado = context.USUARIO.Add(usuario);

                        int idUsuarioAdicionado = usuarioAdicionado.IdUsuario;

                        // Vincula o usuário adicionado ao contato 
                        contatoAdicionado.IdUsuario = idUsuarioAdicionado;

                        USUARIO_GRUPO usuarioGrupo = new USUARIO_GRUPO();
                        usuarioGrupo.IdGrupo = idGrupoProprietario;
                        usuarioGrupo.IdUsuario = idUsuarioAdicionado;
                        usuarioGrupo.FlagAtivo = "S";
                        usuarioGrupo.AdicionaUsuario = (permitirConvidarMembros ? "S" : "N");

                        var usuarioGrupoAdicionado = context.USUARIO_GRUPO.Add(usuarioGrupo);


                        // Envio de e-mail 
                        string nomeGrupo = nomeGrupoProprietario;
                        string titulo = "Convite para participar do grupo " + nomeGrupo;
                        string msg = EmailModelos.GerarMensagemConviteGrupo(nomeGrupo, emailInformado);
                        
                        EmailService.EnviarComRemetenteOrganizadorPessoal(emailInformado, titulo, msg);

                    }
                    else // Convida um usuário de outro grupo para participar do grupo que está em sessão
                    {
                        int idUsuarioInformado = usuarioEncontrado.IdUsuario;

                        // Vincula o usuário encontrado ao contato 
                        contatoAdicionado.IdUsuario = idUsuarioInformado;

                        var usuarioGrupoJaRegistrado = context.USUARIO_GRUPO.FirstOrDefault(m => m.IdGrupo == idGrupoProprietario && m.IdUsuario == idUsuarioInformado);
                        if (usuarioGrupoJaRegistrado == null) // Se for um usuário, mas ainda não está no grupo
                        {
                            USUARIO_GRUPO usuarioGrupo = new USUARIO_GRUPO();
                            usuarioGrupo.IdGrupo = idGrupoProprietario;
                            usuarioGrupo.IdUsuario = idUsuarioInformado;
                            usuarioGrupo.FlagAtivo = "S";
                            usuarioGrupo.AdicionaUsuario = (permitirConvidarMembros ? "S" : "N");

                            context.USUARIO_GRUPO.Add(usuarioGrupo);
                        }
                        
                    }
                }
                else // Condição onde o usuário não envia um convite
                {
                    var usuarioDoGrupo = UsuarioDoGrupo(emailInformado, idGrupoProprietario);
                    if (usuarioDoGrupo != null)
                        contatoAdicionado.IdUsuario = usuarioDoGrupo.IdUsuario;
                }

                // Sincrona no banco
                context.SaveChanges();
                transacao.Commit();
            }
            catch (Exception e)
            {
                transacao.Rollback();
                throw e;
            }

        }

        
        //public List<ValidationResult> ValidarAdicionarContatoComoUsuario(string emailUsuario)
        //{

        //    List<ValidationResult> erros = new List<ValidationResult>();

        //    var aUsuario = context.USUARIO.Where(u => u.Email.Equals(emailUsuario)).FirstOrDefault();

        //    if (aUsuario == null)
        //    {
        //        erros.Add(new ValidationResult("O E-mail informado não é de um usuário do sistema."));
        //    }



        //    return erros;
        //}

        public void Adicionar(string EmailUsuario, int idUsuarioSessao, int idGrupoSessao)
        {
            var transacao = context.Database.BeginTransaction();
            try
            {
                var aUsuario = context.USUARIO.Where(u => u.Email.Equals(EmailUsuario)).FirstOrDefault();

                CONTATO contato = new CONTATO();
                contato.IdUsuarioProprietario = idUsuarioSessao;
                contato.IdGrupoProprietario = idGrupoSessao;
                contato.Nome = aUsuario.Nome;
                contato.Email = aUsuario.Email;
                contato.Telefone = aUsuario.Telefone;
                contato.Endereco = aUsuario.Endereco;
                contato.FlagAtivo = "S";

                context.CONTATO.Add(contato);
                context.SaveChanges();
                transacao.Commit();

            }
            catch (Exception e)
            {
                transacao.Rollback();
                throw e;
            }
        }


        public List<ValidationResult> ValidaAdicionar(CONTATO contato)
        {
            List<ValidationResult> erros = new List<ValidationResult>();

            string emailInformado = contato.Email;
            var usuarioEncontrado = context.USUARIO.Where(m => m.Email.Equals(emailInformado, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
            if (usuarioEncontrado != null) 
            {
                int idUsuarioSessao = contato.IdUsuarioProprietario.Value;
                int idUsuarioEncontrado = usuarioEncontrado.IdUsuario;
                if (idUsuarioEncontrado == idUsuarioSessao) 

                    erros.Add(new ValidationResult(String.Empty, "Informe um e-mail diferente do seu e-mail de login."));
            }

            if (!contato.DataNascimento.HasValue)
                erros.Add(new ValidationResult(String.Empty, "Data de nascimento inválida"));

            if(contato.DataNascimento >= DateTime.Today)
                erros.Add(new ValidationResult(String.Empty, "Informe sua data de nascimento menor que a data atual."));

            return erros;
        }
    }
}