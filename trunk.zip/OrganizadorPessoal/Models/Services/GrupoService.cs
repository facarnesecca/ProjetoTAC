﻿using OrganizadorPessoal.Filtros;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.ViewModels.UsuarioVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.Services
{
    public class GrupoService
    {
        private OrganizadorPessoalContext context; 

        public GrupoService() 
        {
            context = new OrganizadorPessoalContext();    
        }

        public GrupoService(OrganizadorPessoalContext context) 
        {
            this.context = context;
        }

        public List<GRUPO> Listar()
        {
            return context.GRUPO.ToList();
        }

        public void AdicionarAdminGrupo(string nomeGrupo, string emailAdministrador, byte[] bytesImagemGrupo) 
        {
            var transacao = context.Database.BeginTransaction();
            try
            {
                var usuarioEncontrado = context.USUARIO.FirstOrDefault(m => m.Email.Equals(emailAdministrador, StringComparison.InvariantCultureIgnoreCase));
                var usuarioAdicionado = usuarioEncontrado;

                if (usuarioEncontrado == null)
                {
                    USUARIO usuarioAdmGrupo = new USUARIO();
                    usuarioAdmGrupo.Email = emailAdministrador;
                    usuarioAdmGrupo.FlagAtivo = "N";
                    usuarioAdmGrupo.AdmSistema = "N";

                    // Adiciona o usuário adm do grupo e já o retorna
                    usuarioAdicionado = context.USUARIO.Add(usuarioAdmGrupo);
                }
                GRUPO grupo = new GRUPO();
                grupo.Nome = nomeGrupo;
                grupo.Imagem = bytesImagemGrupo;
                // Associa o usuário adicionado ao grupo a ser adicionado
                grupo.IdAdministrador = usuarioAdicionado.IdUsuario;
                var grupoAdicionado = context.GRUPO.Add(grupo);
                
                // Associa o grupo e o usuário adicionados na tabela USUARIO_GRUPO
                USUARIO_GRUPO usuarioGrupo = new USUARIO_GRUPO();
                usuarioGrupo.IdGrupo = grupoAdicionado.IdGrupo;
                usuarioGrupo.IdUsuario = usuarioAdicionado.IdUsuario;
                usuarioGrupo.FlagAtivo = "S";
                usuarioGrupo.AdicionaUsuario = "S";
                context.USUARIO_GRUPO.Add(usuarioGrupo);
                
                context.SaveChanges();

                if (usuarioAdicionado.FlagAtivo == "N")
                {
                    // Envio do e-mail de registro
                    string titulo = "Convite para participar do grupo " + nomeGrupo;
                    string msg = EmailModelos.GerarMensagemConviteGrupo(nomeGrupo, emailAdministrador);

                    EmailService.EnviarComRemetenteOrganizadorPessoal(emailAdministrador, titulo, msg);
                }
                transacao.Commit();
            }
            catch (Exception e)
            {
                transacao.Rollback();
                throw e;
            }


        }

        public List<USUARIO> ListarUsuariosAtivosDoGrupo(int idgrupo)
        {
            var listUserGrupo = context.USUARIO_GRUPO.Where(g => g.IdGrupo.Equals(idgrupo) && g.FlagAtivo.Equals("S") && g.USUARIO.FlagAtivo.Equals("S")).ToList();

            List<USUARIO> listUser = new List<USUARIO>();
            foreach (var aUser in listUserGrupo)
            {
                var aux = context.USUARIO.Where(u => u.IdUsuario.Equals(aUser.IdUsuario)).FirstOrDefault();
                listUser.Add(aux);
            }

            return listUser;
        }

        public GRUPO BuscarPorId(int idGrupo)
        {
            return context.GRUPO.Find(idGrupo);
        }

        public void DesativarUsuarioNoGrupo(int idGrupo, int idUsuario)
        {
            var usuarioGrupo = context.USUARIO_GRUPO.Find(idGrupo, idUsuario);
            usuarioGrupo.FlagAtivo = "N";

            context.SaveChanges();
        }

        public OrganizadorPessoalContext GetContext()
        {
            return context;
        }

        public List<ValidationResult> ValidarNomeDoGrupo(string nomeGrupo)
        {
            List<ValidationResult> erros = new List<ValidationResult>();

            var nomeDoGrupoInvalido = context.GRUPO.FirstOrDefault(m => m.Nome.Equals(nomeGrupo, StringComparison.InvariantCultureIgnoreCase));
            if (nomeDoGrupoInvalido != null)
                erros.Add(new ValidationResult("Grupo já cadastrado"));

            return erros;
        }
        //public List<ValidationResult> ValidarAdicionarAdminGrupo(string emailAdministradorGrupo)
        //{
        //    List<ValidationResult> erros = new List<ValidationResult>();

        //    var usuarioEncontrado = context.USUARIO.FirstOrDefault(m => m.Email.Equals(emailAdministradorGrupo, StringComparison.InvariantCultureIgnoreCase));
        //    if (usuarioEncontrado != null)
        //    {
        //        erros.Add(new ValidationResult(string.Empty, "Este e-mail já está sendo utilizado por algum usuário do sistema."));
        //    }

        //    return erros;

        //}

        public List<GRUPO> ListarGruposDoUsuario(int idUsuario)
        {
            USUARIO usuario = context.USUARIO.FirstOrDefault(u => u.IdUsuario == idUsuario);

            ICollection<USUARIO_GRUPO> usuarioGrupo = usuario.USUARIO_GRUPO;

            List<GRUPO> grupos = new List<GRUPO>();
            foreach (var item in usuarioGrupo)
            {
                grupos.Add(item.GRUPO);
            }

            return grupos;
        }
    }
}