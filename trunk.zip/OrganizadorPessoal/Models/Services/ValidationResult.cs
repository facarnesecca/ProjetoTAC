﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.Services
{
    // Descreve o resultado de uma validação da camada de regra de negócio
    public class ValidationResult
    {
        public string Nome { get; set; }
        public string Mensagem { get; set; }

        public ValidationResult()
        { }

        public ValidationResult(string mensagem)
        {
            Nome = string.Empty;
            Mensagem = mensagem;
        }

        public ValidationResult(string nome, string mensagem)
        {
            Nome = nome;
            Mensagem = mensagem;
        }
    }
}