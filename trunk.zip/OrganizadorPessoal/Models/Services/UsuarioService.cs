﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.Services
{
    public class UsuarioService
    {

        private OrganizadorPessoalContext context;

        public UsuarioService() 
        {
            context = new OrganizadorPessoalContext();    
        }

        public UsuarioService(OrganizadorPessoalContext context)
        {
            this.context = context;
        }

        public List<ValidationResult> ValidarAutenticacao(string email, string senha)
        {
            List<ValidationResult> erros = new List<ValidationResult>();

            USUARIO usuario = context.USUARIO.Where(u => u.Email.Equals(email) && u.Senha.Equals(senha)).FirstOrDefault();

            if (usuario == null)
            {
                erros.Add(new ValidationResult("E-mail e/ou senha inválidos."));
            }
            else
            { 
                if (!usuario.FlagAtivo.Equals("S"))
                    erros.Add(new ValidationResult(
                        "Ative o seu cadastro através do link fornecido no email de ativação. " + 
                        "Caso não tenha recebido o email ou algum outro problema tenha acontecido, contate o suporte."));

            }

            return erros;

        }

        // Retorna o USUARIO ou NULL
        public USUARIO Autenticar(string email, string senha)
        {
            USUARIO usuario = context.USUARIO.Where(u => u.Email.Equals(email) && u.Senha.Equals(senha)).FirstOrDefault();

            return usuario;
        }

        public void Adicionar(USUARIO usuario)
        {
            context.USUARIO.Add(usuario);

            context.SaveChanges();
        }

        public USUARIO Atualizar(int idUsuario, string nome, string senha, string telefone, string endereco, byte[] bytesFoto)
        {
            var aUsuario = context.USUARIO.Find(idUsuario);
            aUsuario.Nome = nome;
            aUsuario.Senha = senha;
            aUsuario.Telefone = telefone;
            aUsuario.Endereco = endereco;
            aUsuario.Foto = bytesFoto;

            context.SaveChanges();

            return aUsuario;
        }

        public bool ValidarSenha(int idUsuario, string senha)
        {
            bool senhaInformadaCorresponde = true;

            var usuario = context.USUARIO.Find(idUsuario);

            if (!usuario.Senha.Equals(senha))
                senhaInformadaCorresponde = false;

            return senhaInformadaCorresponde;
        }

        public List<USUARIO> Listar()
        {
            return context.USUARIO.ToList();
        }

        public USUARIO BuscarPorId(int id)
        {
            return context.USUARIO.Find(id);
        }



        public void Remover(int id)
        {
            var usuario = context.USUARIO.Find(id);
            context.USUARIO.Remove(usuario);
            
            context.SaveChanges();
        }

        public USUARIO BuscarPorEmail(string email)
        {
            var usuario = context.USUARIO.Where(u => u.Email.Equals(email)).FirstOrDefault();
            return usuario;
        }


        public USUARIO Registrar(string email, string nome, string telefone, string endereco, string senha, byte[] bytesFoto)
        {
            USUARIO usuario = BuscarPorEmail(email);
            usuario.Nome = nome;
            usuario.Telefone = telefone;
            usuario.Endereco = endereco;
            usuario.Senha = senha;
            usuario.Foto = bytesFoto;
            usuario.FlagAtivo = "S"; // Ativa o registro

            context.SaveChanges();

            return usuario;

        }

        public int QuantidadeGruposDoUsuario(int idUsuario)
        {
            return context.USUARIO_GRUPO.Where(u => u.IdUsuario == idUsuario).Count();
        }

        public GRUPO BuscarGrupoDoUsuario(int idUsuario)
        {
            var usuarioGrupo = context.USUARIO_GRUPO.Where(m => m.IdUsuario == idUsuario).FirstOrDefault();

            if (usuarioGrupo != null)
                return usuarioGrupo.GRUPO;
            else
                return null;
        }

        public List<GRUPO> ListarGruposAtivosDoUsuario(int idUsuario)
        {
            var usuarioGrupoRegistros = context.USUARIO_GRUPO.Where(m => m.IdUsuario == idUsuario && m.FlagAtivo.Equals("S"));

            List<GRUPO> grupos = new List<GRUPO>();
            foreach (var item in usuarioGrupoRegistros)
            {
                grupos.Add(item.GRUPO);
            }

            return grupos;
        }



        public bool PodeConvidarNovosMembrosParaOGrupo(int idUsuario, int idGrupo)
        {
            var UG = context.USUARIO_GRUPO.Where(m => m.IdUsuario == idUsuario && m.IdGrupo == idGrupo).FirstOrDefault();

            return UG.AdicionaUsuario.Equals("S");
        }

        public USUARIO BuscarPorEmailSenha(string email, string senha)
        {
            USUARIO usuario = context.USUARIO.FirstOrDefault(u => u.Email.Equals(email) && u.Senha.Equals(senha) && u.FlagAtivo.Equals("S"));
            return usuario;
        }
    }
}