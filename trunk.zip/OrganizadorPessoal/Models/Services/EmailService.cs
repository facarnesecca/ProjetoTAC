﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;
using System.Net;

namespace OrganizadorPessoal.Models.Services
{
    public class EmailService
    {
        // TODO ATIVAR EM PRODUÇÃO
        private const bool ENVIO_EMAIL_ATIVO = true;

        private const string REMETENTE = "orgpessoalps@gmail.com";
        private const string SENHA = "barao123";
        private const string NOME_EMAIL = "Organizador Pessoal";
        private const string HOST = "smtp.gmail.com";
        private const bool SSL = true;
        private const int PORTA = 587;


        /// <summary>
        /// Envia e-mail usando os dados do organizador pessoal como remetente
        /// </summary>
        /// <param name="emailsDestinatario">E-mails dos destinários</param>
        /// <param name="assunto">Assunto do e-mail</param>
        /// <param name="corpoMensagem">Mensagem do e-mail</param>
        public static void EnviarEmMassaComRemetenteOrganizadorPessoal(
            List<string> emailsDestinatario, string assunto, string corpoMensagem)
        {
            EnviarEmMassa(HOST, SSL,
                REMETENTE, SENHA, NOME_EMAIL,
                emailsDestinatario, assunto, corpoMensagem);
        }


        /// <summary>
        /// Envia e-mail usando os dados do organizador pessoal como remetente
        /// </summary>
        /// <param name="emailsDestinatario">E-mail do destinário</param>
        /// <param name="assunto">Assunto do e-mail</param>
        /// <param name="corpoMensagem">Mensagem do e-mail</param>
        public static void EnviarComRemetenteOrganizadorPessoal(
            string emailDestinatario, string assunto, string corpoMensagem)
        {
            Enviar(HOST, SSL,
                REMETENTE, SENHA, NOME_EMAIL,
                emailDestinatario, assunto, corpoMensagem);
        }



        /// <summary>
        /// Envia e-mail para vários destinatários
        /// </summary>
        /// <param name="hostEmail">Endereço Host do remetente</param>
        /// <param name="ssl">Security Socket Layer</param>
        /// <param name="emailRemetente">Endereço do e-mail remetente</param>
        /// <param name="senhaEmail">Senha do e-mail do remetente</param>
        /// <param name="nomeEmail">Nome que aparece no e-mail</param>
        /// <param name="emailsDestinatario">Destinatários</param>
        /// <param name="assunto">Assunto do e-mail</param>
        /// <param name="corpoMensagem">Mensagem do e-mail</param>
        public static void EnviarEmMassa(string hostEmail, bool ssl, string emailRemetente, string senhaEmail, string nomeEmail,
            List<string> emailsDestinatario, string assunto, string corpoMensagem)
        {

            if (ENVIO_EMAIL_ATIVO)
            {
                try
                {
                    MailMessage emailObj = new MailMessage();
                    emailObj.IsBodyHtml = true; // Indica que aceita mensagem em html
                    emailObj.From = new MailAddress(emailRemetente, nomeEmail);

                    foreach (var email in emailsDestinatario)
                    {
                        emailObj.To.Add(new MailAddress(email));
                    }

                    emailObj.Subject = assunto;
                    emailObj.Body = corpoMensagem;

                    // Configura o cliente de acesso de email
                    SmtpClient cliente = new SmtpClient();
                    cliente.Host = hostEmail;
                    cliente.EnableSsl = ssl;
                    cliente.Port = PORTA;
                    cliente.Credentials = new NetworkCredential(emailRemetente,
                        senhaEmail);

                    cliente.Send(emailObj);
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }


        /// <summary>
        /// Envia e-mail para um destinatário
        /// </summary>
        /// <param name="hostEmail">Endereço Host do remetente</param>
        /// <param name="ssl">Security Socket Layer</param>
        /// <param name="emailRemetente">Endereço do e-mail remetente</param>
        /// <param name="senhaEmail">Senha do e-mail do remetente</param>
        /// <param name="nomeEmail">Nome que aparece no e-mail</param>
        /// <param name="emailDestinatario">Destinatários</param>
        /// <param name="assunto">Assunto do e-mail</param>
        /// <param name="corpoMensagem">Mensagem do e-mail</param>
        public static void Enviar(string hostEmail, bool ssl, string emailRemetente, string senhaEmail, string nomeEmail,
            string emailDestinatario, string assunto, string corpoMensagem)
        {


            if (ENVIO_EMAIL_ATIVO)
            {

                try
                {
                    MailMessage emailObj = new MailMessage();
                    emailObj.IsBodyHtml = true; // Indica que aceita mensagem em html
                    emailObj.From = new MailAddress(emailRemetente, nomeEmail);

                    emailObj.To.Add(new MailAddress(emailDestinatario));

                    emailObj.Subject = assunto;
                    emailObj.Body = corpoMensagem;

                    // Configura o cliente de acesso de email
                    SmtpClient cliente = new SmtpClient();
                    cliente.Host = hostEmail;
                    cliente.EnableSsl = ssl;
                    cliente.Port = PORTA;
                    cliente.Credentials = new NetworkCredential(emailRemetente,
                        senhaEmail);

                    cliente.Send(emailObj);
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
        }
    }
}