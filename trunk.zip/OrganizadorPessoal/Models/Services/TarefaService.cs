﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Objects;

namespace OrganizadorPessoal.Models.Services
{
    public class TarefaService
    {
        private OrganizadorPessoalContext context;

        public TarefaService()
        {
            context = new OrganizadorPessoalContext();
        }

        public TarefaService(OrganizadorPessoalContext context)
        {
            this.context = context;
        }

        public TAREFA BuscarPorId(int id)
        {
            TAREFA tarefa = context.TAREFA.Where(m => m.IdTarefa == id && m.FlagAtivo.Equals("S")).FirstOrDefault();

            return tarefa;
        }

        public void Adicionar(TAREFA tarefa)
        {
            // Se o proprietário fez a tarefa para ele mesmo, a tarefa é aceita automaticamente.
            // caso contrário, fica pendente à espera da posição do executor
            if (tarefa.IdProprietario == tarefa.IdExecutor || tarefa.IdExecutor == null)
                tarefa.Estado = "A";
            else
                tarefa.Estado = "P";
            tarefa.FlagAtivo = "S";

            var tarefaAdicionadaParcial = context.TAREFA.Add(tarefa);
            context.SaveChanges();

            int idTarefaAdicionada = tarefaAdicionadaParcial.IdTarefa;

            // Envio do e-mail
            if (tarefa.IdExecutor != tarefa.IdProprietario)
            {                
                // Recarrega o context para que seja possível navegar entre as entidades relacionadas da tarefa adicionada
                context = new OrganizadorPessoalContext();

                TAREFA tarefaAdicionada = context.TAREFA.Find(idTarefaAdicionada);

                var usuarioProprietario = tarefaAdicionada.USUARIO_GRUPO.USUARIO;
                var usuarioExecutor = tarefaAdicionada.USUARIO_GRUPO1.USUARIO;
                var grupo = tarefaAdicionada.USUARIO_GRUPO.GRUPO;

                string emailUsuarioDestinatario = usuarioExecutor.Email;

                string nomeProprietarioTarefa = usuarioProprietario.Nome;
                string nomeReceptorTarefa = usuarioExecutor.Nome;
                string nomeGrupo = grupo.Nome;
                string tituloTarefa = tarefaAdicionada.Titulo;
                string dateTimeTarefa = tarefaAdicionada.DataInicio.ToString("dd/MM/yyyy hh:mm");
                string descricaoTarefa = tarefaAdicionada.Descricao;

                string tituloEmail = "Atribuição de tarefa no grupo " + nomeGrupo;
                string msgEmail = EmailModelos.GerarMensagemAtribuicaoTarefa(nomeProprietarioTarefa,
                    nomeReceptorTarefa, nomeGrupo, tituloTarefa, dateTimeTarefa, descricaoTarefa);

                EmailService.EnviarComRemetenteOrganizadorPessoal(emailUsuarioDestinatario, tituloEmail, msgEmail);    
            }

        }

        public TAREFA Atualizar(int idTarefa, string observacao)
        {
            var tarefa = context.TAREFA.Find(idTarefa);
            tarefa.Observacao = observacao;

            context.SaveChanges();

            return tarefa;
        }

        public void Desativar(int id)
        {
            TAREFA tarefa = context.TAREFA.Where(t => t.IdTarefa.Equals(id)).FirstOrDefault();
            tarefa.FlagAtivo = "N";

            context.SaveChanges();
        }

        public TAREFA AtualizarEstado(int idTarefa, string estado)
        {
            var tarefa = context.TAREFA.Find(idTarefa);
            tarefa.Estado = estado;

            context.SaveChanges();

            return tarefa;
        }

        public List<ValidationResult> ValidarAdicionarTarefa(TAREFA tarefa)
        {
            List<ValidationResult> erros = new List<ValidationResult>();

            bool dataInicioInvalida = tarefa.DataInicio <= DateTime.Now.AddMinutes(10);
            if (dataInicioInvalida)
                erros.Add(new ValidationResult("Não é possível cadastrar tarefas iniciadas em menos de 10 minutos"));

            bool dataTerminoInvalida = tarefa.DataTermino != null && 
                                        tarefa.DataInicio < tarefa.DataTermino &&
                                        tarefa.DataTermino < tarefa.DataInicio.AddMinutes(10);
            if (dataTerminoInvalida)
                erros.Add(new ValidationResult("O tempo mínimo para a execução da tarefas é de 10 minutos"));

            bool dataInicioTerminoInvalida = tarefa.DataTermino != null &&
                                            tarefa.DataTermino <= tarefa.DataInicio;
            if (dataInicioTerminoInvalida)
                erros.Add(new ValidationResult("A data de término deverá ocorrer após a data de início"));

            bool executorInvalido = tarefa.IdExecutor <= 0;
            if (executorInvalido)
                erros.Add(new ValidationResult("Executor da tarefa inválido"));

            return erros;
        }

        public List<ValidationResult> ValidarAtualizarTarefa(TAREFA tarefa)
        {
            List<ValidationResult> erros = new List<ValidationResult>();

            bool observacaoInvalida = tarefa.Observacao.Length > 2000;
            if (observacaoInvalida)
                erros.Add(new ValidationResult("O campo observação deve ter no máximo 2000 caracteres"));

            return erros;
        }

        public List<TAREFA> ListarTarefasDelegadas(int idProprietario, int idGrupo)
        {
            List<TAREFA> tarefas = context.TAREFA.Where(m => m.IdProprietario == idProprietario && 
                                                            m.IdGrupoProprietario == idGrupo &&
                                                            m.IdExecutor != null &&
                                                            m.IdExecutor != m.IdProprietario &&
                                                            m.FlagAtivo.Equals("S")).OrderByDescending(d=>d.DataInicio).ToList();
            
            return tarefas;
        }

        public List<TAREFA> ListarTarefasExecutor(int idExecutor, int idGrupo)
        {
            var lista = context.TAREFA.Where(m => m.IdExecutor == idExecutor && 
                                                m.IdGrupoExecutor == idGrupo && 
                                                m.FlagAtivo.Equals("S")).OrderByDescending(d=> d.DataInicio);

            List<TAREFA> tarefas = new List<TAREFA>();
            foreach (var item in lista)
            {
                tarefas.Add(item);
            }
            return tarefas;
        }

        public List<TAREFA> ListarTarefasPorData(int idExecutor, int idGrupo, DateTime dataInicio)
        {
            DateTime finalDoDia = dataInicio.AddHours(23).AddMinutes(59); 

            var lista = context.TAREFA.Where(
                            m => m.IdExecutor == idExecutor && 
                                m.IdGrupoExecutor == idGrupo && 
                                m.DataInicio >= dataInicio &&
                                m.DataInicio <= finalDoDia &&
                                m.FlagAtivo.Equals("S"));

            List<TAREFA> tarefas = new List<TAREFA>();
            foreach (var item in lista)
            {
                tarefas.Add(item);
            }
            return tarefas;
        }

        public List<TAREFA> ListarTarefasAceitasDoDia(int idExecutor, int idGrupo, DateTime dataPesquisa)
        {
            DateTime finalDoDia = dataPesquisa.AddHours(23).AddMinutes(59);
            // Ver data final
            List<TAREFA> lista = context.TAREFA.Where(m => m.IdExecutor == idExecutor && m.IdGrupoExecutor == idGrupo &&
                                ((dataPesquisa <= m.DataInicio && m.DataInicio <= finalDoDia) ||
                                (m.DataInicio <= dataPesquisa &&  dataPesquisa <= m.DataTermino.Value) ||
                                (dataPesquisa <= m.DataTermino && m.DataTermino <= finalDoDia)) && 
                                m.Estado.Equals("A") &&
                                m.FlagAtivo.Equals("S")).ToList();

            return lista;
        }

        public List<TAREFA> ListarTarefasPendentes(int idExecutor, int idGrupo)
        {
            return context.TAREFA.Where(t => t.IdExecutor == idExecutor &&
                                            t.IdGrupoExecutor == idGrupo &&
                                            t.Estado.Equals("P") &&
                                            t.FlagAtivo.Equals("S")).ToList();
        }

        public List<TAREFA> ListarTarefasConcluidas(int idExecutor, int idGrupo)
        {
            return context.TAREFA.Where(t => t.IdExecutor == idExecutor &&
                                            t.IdGrupoExecutor == idGrupo &&
                                            (t.Estado.Equals("C") || t.Estado.Equals("R") || t.Estado.Equals("A")) &&
                                            t.FlagAtivo.Equals("S")).ToList();
        }

        // TODO Adicionar uma tarefa para um contato-usuário relacionada à um compromisso


        public List<TAREFA> ListarProximasTarefasDoUsuario(int idUsuario, int idGrupo)
        {
            DateTime dtNow = DateTime.Now;
            var query = context.TAREFA.Where(t => t.IdExecutor == idUsuario && t.IdGrupoExecutor == idGrupo 
                && t.DataInicio > dtNow && t.FlagAtivo.Equals("S"));
            return query.OrderBy(t => t.DataInicio).ToList();
        }
    }
}