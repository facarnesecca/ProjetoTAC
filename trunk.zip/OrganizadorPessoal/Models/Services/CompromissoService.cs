﻿using OrganizadorPessoal.Controllers;
using OrganizadorPessoal.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models
{
    public class CompromissoService
    {

        private OrganizadorPessoalContext context;

        public CompromissoService()
        {
            context = new OrganizadorPessoalContext();
        }

        public CompromissoService(OrganizadorPessoalContext context)
        {
            this.context = context;
        }

        public OrganizadorPessoalContext GetContext()
        {
            return this.context;
        }

        public COMPROMISSO BuscarPorId(int id)
        {
            COMPROMISSO compromisso = context.COMPROMISSO.Where(c => c.IdCompromisso.Equals(id) && c.FlagAtivo.Equals("S")).FirstOrDefault();

            return compromisso;
        }

        public bool AceitarCompromisso(int idCompromisso, int idContato)
        {
            var cp = context.COMPROMISSO_CONTATOS.FirstOrDefault(m => m.IdCompromisso == idCompromisso && m.IdContato == idContato);
            if (cp == null)
                return false;

            cp.Estado = "A";
            context.SaveChanges();

            return true;
        }

        public bool RejeitarCompromisso(int idCompromisso, int idContato)
        {
            var cp = context.COMPROMISSO_CONTATOS.FirstOrDefault(m => m.IdCompromisso == idCompromisso && m.IdContato == idContato);
            if (cp == null)
                return false;

            cp.Estado = "R";
            context.SaveChanges();

            return true;
        }

        public void RemoverParticipacao(int idCompromisso, int idContato)
        {
            var cp = context.COMPROMISSO_CONTATOS.FirstOrDefault(m => m.IdCompromisso.Equals(idCompromisso) && m.IdContato.Equals(idContato));
            if (cp != null)
            {
                cp.FlagAtivo = "N";
                context.SaveChanges();
            }
        }

        public void Adicionar(COMPROMISSO compromisso, List<CONTATO> colaboradores, string nomeUsuarioProprietario, string nomeGrupoProprietario)
        {
            int idGrupo = compromisso.IdGrupo.Value;

            var transacao = context.Database.BeginTransaction();
            try
            {
                compromisso.FlagAtivo = "S";
                // Adiciona e retorna o compromisso
                var compromissoAdicionado = context.COMPROMISSO.Add(compromisso);
                context.SaveChanges();

                int idCompromisso = compromissoAdicionado.IdCompromisso;

                // O compromisso possui ao menos um colaborador
                bool compromissoCompartilhado = colaboradores != null;

                List<HolderEmailContato> listaEmailsColaboradores = null;
                if (compromissoCompartilhado)
                {

                    foreach (var colaborador in colaboradores)
                    {
                        // Salva em COMPROMISSO_CONTATO todos os colaboradores
                        COMPROMISSO_CONTATOS compromissoContatos = new COMPROMISSO_CONTATOS();
                        compromissoContatos.IdCompromisso = idCompromisso;
                        compromissoContatos.IdContato = colaborador.IdContato;
                        compromissoContatos.FlagAtivo = "S";
                        compromissoContatos.Estado = "P";

                        // se o contato for um usuário, associa o idUsuario na tabela compromisso_contato
                        var usuarioEncontrado = context.USUARIO.FirstOrDefault(u => u.Email.Equals(colaborador.Email));
                        if (usuarioEncontrado != null)
                        {
                            compromissoContatos.IdColaborador = usuarioEncontrado.IdUsuario;
                            compromissoContatos.IdGrupoColaborador = idGrupo;
                        }

                        // Insert
                        var compromissoContatoAdicionado = context.COMPROMISSO_CONTATOS.Add(compromissoContatos);
                        context.SaveChanges();

                        if (!string.IsNullOrEmpty(colaborador.Email))
                        {
                            if (listaEmailsColaboradores == null)
                                listaEmailsColaboradores = new List<HolderEmailContato>();

                            int idContato = compromissoContatoAdicionado.IdContato;

                            listaEmailsColaboradores.Add(new HolderEmailContato
                                                             {
                                                                 Nome = colaborador.Nome,
                                                                 Email = colaborador.Email,
                                                                 IdContato = idContato
                                                             });
                        }
                    }
                }

                // Sincroniza 
                context.SaveChanges();

                // Envio dos e-mails
                if (listaEmailsColaboradores != null)
                {

                    string nomeProprietarioCompromisso = nomeUsuarioProprietario;
                    string nomeGrupo = nomeGrupoProprietario;
                    string tituloCompromisso = compromissoAdicionado.Titulo;
                    string dataHoraCompromisso = compromissoAdicionado.DataInicio.ToString("dd/MM/yyyy hh:mm");
                    string descricaoCompromisso = compromissoAdicionado.Descricao;

                    foreach (var item in listaEmailsColaboradores)
                    {
                        string nomeConvidado = item.Nome;
                        int idContato = item.IdContato;

                        string msg = EmailModelos.GerarMensagemConviteCompromisso(nomeConvidado,
                                                        nomeProprietarioCompromisso, nomeGrupo,
                                                        tituloCompromisso, dataHoraCompromisso,
                                                        descricaoCompromisso, idCompromisso, idContato);

                        string emailConvidado = item.Email;
                        string assuntoEmail = "Convite para o compromisso " + tituloCompromisso;
                        EmailService.EnviarComRemetenteOrganizadorPessoal(emailConvidado, assuntoEmail, msg);

                    }
                }

                // Commit da transação
                transacao.Commit();
            }
            catch (Exception e)
            {
                transacao.Rollback();
                throw e;
            }

        }

        public void Atualizar(COMPROMISSO compromisso, List<CONTATO> colaboradores, string nomeUsuarioProprietario, string nomeGrupoProprietario)
        {
            int idGrupo = compromisso.IdGrupo.Value;

            var transacao = context.Database.BeginTransaction();
            try
            {
                var aCompromisso = context.COMPROMISSO.Find(compromisso.IdCompromisso);
                aCompromisso.DataInicio = compromisso.DataInicio;
                aCompromisso.DataTermino = compromisso.DataTermino;
                aCompromisso.Descricao = compromisso.Descricao;
                //aCompromisso.Titulo = compromisso.Titulo; Não atualiza o titulo

                context.SaveChanges();

                var colaboradoresAntigos = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdCompromisso == compromisso.IdCompromisso &&
                                                cc.FlagAtivo.Equals("S")).ToList();

                // Lista de colaboradores antigos
                List<CONTATO> antigos = new List<CONTATO>();
                foreach (var colaborador in colaboradoresAntigos)
                {
                    antigos.Add(context.CONTATO.Where(c => c.IdContato == colaborador.IdContato).FirstOrDefault());
                }

                // Remover os colaboradores que não farão mais parte do compromisso
                var excluidos = ColaboradoresExcluidos(antigos, colaboradores);
                foreach (var excluido in excluidos)
                {
                    COMPROMISSO_CONTATOS colaborador = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdContato == excluido.IdContato &&
                                                            cc.IdCompromisso == compromisso.IdCompromisso).FirstOrDefault();
                    colaborador.FlagAtivo = "N";   

                    // enviar emails
                }

                List<HolderEmailContato> listaEmailsColaboradores = null;

                // Adicionar os novos colaboradores
                var adicionados = ColaboradoresNovos(antigos, colaboradores);
                foreach (var colaborador in adicionados)
                {
                    // Salva em COMPROMISSO_CONTATO todos os colaboradores

                    // Verifica se o usuário já estava cadastrado anteriormente
                    var cadastroAntigo = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdContato == colaborador.IdContato &&
                                            cc.IdCompromisso == compromisso.IdCompromisso).FirstOrDefault();
                    if (cadastroAntigo != null)
                    {
                        cadastroAntigo.FlagAtivo = "S";
                        context.SaveChanges();
                    }
                    else
                    {

                        COMPROMISSO_CONTATOS compromissoContatos = new COMPROMISSO_CONTATOS();
                        compromissoContatos.IdCompromisso = compromisso.IdCompromisso;
                        compromissoContatos.IdContato = colaborador.IdContato;
                        compromissoContatos.FlagAtivo = "S";
                        compromissoContatos.Estado = "P";

                        // se o contato for um usuário, associa o idUsuario na tabela compromisso_contato
                        var usuarioEncontrado = context.USUARIO.FirstOrDefault(u => u.Email.Equals(colaborador.Email));
                        if (usuarioEncontrado != null)
                        {
                            compromissoContatos.IdColaborador = usuarioEncontrado.IdUsuario;
                            compromissoContatos.IdGrupoColaborador = idGrupo;
                        }

                        // Insert
                        var compromissoContatoAdicionado = context.COMPROMISSO_CONTATOS.Add(compromissoContatos);
                        context.SaveChanges();

                        if (!string.IsNullOrEmpty(colaborador.Email))
                        {
                            if (listaEmailsColaboradores == null)
                                listaEmailsColaboradores = new List<HolderEmailContato>();

                            int idContato = compromissoContatoAdicionado.IdContato;

                            listaEmailsColaboradores.Add(new HolderEmailContato
                                                             {
                                                                 Nome = colaborador.Nome,
                                                                 Email = colaborador.Email,
                                                                 IdContato = idContato
                                                             });
                        }
                    }
                }

                // Commit da transação
                transacao.Commit();
            }
            catch (Exception)
            {
                transacao.Rollback();
            }

        }

        private List<CONTATO> ColaboradoresExcluidos(List<CONTATO> antigos, List<CONTATO> novos)
        {
            List<CONTATO> excluidos = new List<CONTATO>(antigos);
            foreach (var colaborador in novos)
            {
                excluidos.RemoveAll(c=>c.IdContato == colaborador.IdContato);

            }
            

            return excluidos;
        }

        private List<CONTATO> ColaboradoresNovos(List<CONTATO> antigos, List<CONTATO> novos)
        {
            List<CONTATO> adicionados = new List<CONTATO>(novos);
            foreach (var colaborador in antigos)
            {
                adicionados.RemoveAll(c=>c.IdContato == colaborador.IdContato);
            }

            return adicionados;
        }


        public void Desativar(int id)
        {
            COMPROMISSO compromisso = context.COMPROMISSO.Where(c => c.IdCompromisso == id).FirstOrDefault();
            compromisso.FlagAtivo = "N";
            
            List<COMPROMISSO_CONTATOS> compromissoContatos = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdCompromisso == id).ToList();
            foreach (var colaborador in compromissoContatos)
            {
                colaborador.FlagAtivo = "N";
                //envia um email informando
            }

            // Desativa as tarefas relacionadas a este compromisso
            List<TAREFA> tarefasDoCompromisso = context.TAREFA.Where(t => t.IdCompromisso == id).ToList();
            if (tarefasDoCompromisso.Count > 0)
            {
                TarefaService tarefaService = new TarefaService();
                foreach (var tarefa in tarefasDoCompromisso)
                {
                    tarefaService.Desativar(tarefa.IdTarefa);
                }    
            }
            
            context.SaveChanges();
        }

        public List<ValidationResult> ValidarAdicionarCompromisso(COMPROMISSO compromisso)
        {
            List<ValidationResult> erros = new List<ValidationResult>();

            bool dataInicioInvalida = compromisso.DataInicio <= DateTime.Now.AddMinutes(10);
            if (dataInicioInvalida)
                erros.Add(new ValidationResult("Não é possível cadastrar compromissos iniciados em menos de 10 minutos"));

            bool dataTerminoInvalida = compromisso.DataInicio < compromisso.DataTermino &&
                                        compromisso.DataTermino < compromisso.DataInicio.AddMinutes(10);
            if (dataTerminoInvalida)
                erros.Add(new ValidationResult("O tempo mínimo para a execução do compromisso é de 10 minutos"));

            bool dataInicioTerminoInvalida = compromisso.DataTermino <= compromisso.DataInicio;
            if (dataInicioTerminoInvalida)
                erros.Add(new ValidationResult("A data de término deverá ocorrer após a data de início"));



            return erros;
        }

        public List<COMPROMISSO> ListarCompromissosProprietario(int idProprietario, int idGrupo)
        {
            List<COMPROMISSO> compromissos = context.COMPROMISSO.Where(m => m.IdProprietario == idProprietario &&
                                                            m.IdGrupo == idGrupo &&
                                                            m.FlagAtivo.Equals("S")).OrderByDescending(d => d.DataInicio).ToList();

            return compromissos;
        }

        public void RemoverParticipanteDeMeusCompromissos(int idContato)
        {

            var sessao = (SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR];
            var compromissosProprietario = ListarCompromissosProprietario(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo);

            foreach (var item in compromissosProprietario)
            {
                COMPROMISSO_CONTATOS compromisso_contato = item.COMPROMISSO_CONTATOS.FirstOrDefault(m => m.IdCompromisso.Equals(item.IdCompromisso) && m.IdContato.Equals(idContato));
                if (compromisso_contato != null)
                {
                    compromisso_contato.FlagAtivo = "N";
                    context.SaveChanges();
                }
            }

        }

        public List<COMPROMISSO> ListarCompromissosAceitosDoDia(int idUsuario, int idGrupo, DateTime dataPesquisa)
        {
            DateTime finalDoDia = dataPesquisa.AddHours(23).AddMinutes(59);

            List<COMPROMISSO> compromissos = ListarCompromissosAceitos(idUsuario, idGrupo).Where(
                                                d => dataPesquisa.Date == d.DataInicio.Date &&
                                                (dataPesquisa <= d.DataInicio && d.DataInicio <= finalDoDia) ||
                                                (d.DataInicio <= dataPesquisa && dataPesquisa <= d.DataTermino) ||
                                                (dataPesquisa <= d.DataTermino && d.DataTermino <= finalDoDia)).ToList();


            //List<COMPROMISSO> compromissos = ListarCompromissos(idUsuario, idGrupo).Where(
            //                                    d => dataPesquisa.Date == d.DataInicio.Date &&
            //                                    (dataPesquisa <= d.DataInicio && d.DataInicio <= finalDoDia) ||
            //                                    (d.DataInicio <= dataPesquisa && dataPesquisa <= d.DataTermino) ||
            //                                    (dataPesquisa <= d.DataTermino && d.DataTermino <= finalDoDia) &&
            //                                    d.FlagAtivo.Equals("S")).ToList();

            return compromissos;
        }

        // Diferentemente da tarefa, também mostra os compromissos em que o usuário é proprietário
        public List<COMPROMISSO> ListarCompromissos(int idUsuario, int idGrupoUsuario)
        {
            // Compromissos em que o usuário é apenas um colaborador
            var compromissoContatos = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdColaborador.Value == idUsuario &&
                                                                             cc.IdGrupoColaborador.Value == idGrupoUsuario &&
                                                                             cc.FlagAtivo.Equals("S")).ToList();

            List<COMPROMISSO> compromissos = new List<COMPROMISSO>();
            foreach (var linha in compromissoContatos)
            {
                COMPROMISSO compromisso = context.COMPROMISSO.Where(c => c.IdCompromisso == linha.IdCompromisso).FirstOrDefault();
                compromissos.Add(compromisso);
            }

            // Adiciona os compromissos em que o usuário é proprietário
            var compromissosProprietario = ListarCompromissosProprietario(idUsuario, idGrupoUsuario);
            compromissos.AddRange(compromissosProprietario);

            compromissos.OrderByDescending(d => d.DataInicio);

            return compromissos;
        }

        public List<COMPROMISSO> ListarProximosCompromissosDoUsuario(int idUsuario, int idGrupo)
        {
            List<COMPROMISSO> compromissos = ListarCompromissos(idUsuario, idGrupo);
            
            DateTime dtNow = DateTime.Now;
            List<COMPROMISSO> proximosCompromissos = compromissos.Where(c => c.DataInicio > dtNow).OrderBy(c => c.DataInicio).ToList();

            return proximosCompromissos;
        }

        public List<COMPROMISSO> ListarCompromissosAceitos(int idUsuario, int idGrupo)
        {
            var compromissosContatos = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdColaborador.Value == idUsuario &&
                                                            cc.IdGrupoColaborador == idGrupo &&
                                                            cc.Estado.Equals("A") &&
                                                            cc.FlagAtivo.Equals("S")).ToList();

            List<COMPROMISSO> compromissos = new List<COMPROMISSO>();
            foreach (var linha in compromissosContatos)
            {
                COMPROMISSO compromisso = context.COMPROMISSO.Where(c => c.IdCompromisso == linha.IdCompromisso).FirstOrDefault();
                compromissos.Add(compromisso);
            }

            // Adiciona os compromissos em que o usuário é proprietário
            var compromissosProprietario = ListarCompromissosProprietario(idUsuario, idGrupo);
            compromissos.AddRange(compromissosProprietario);


            return compromissos;
        }

        public List<COMPROMISSO> ListarCompromissosPendentes(int idColaborador, int idGrupo)
        {
            var compromissosContatos = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdColaborador.Value == idColaborador &&
                                                            cc.IdGrupoColaborador == idGrupo &&
                                                            cc.Estado.Equals("P") &&
                                                            cc.FlagAtivo.Equals("S")).ToList();

            List<COMPROMISSO> compromissos = new List<COMPROMISSO>();
            foreach (var linha in compromissosContatos)
            {
                COMPROMISSO compromisso = context.COMPROMISSO.Where(c => c.IdCompromisso == linha.IdCompromisso).FirstOrDefault();
                compromissos.Add(compromisso);
            }

            return compromissos;
        }

        public string InformaEstadoCompromisso(int idCompromisso, int idUsuario)
        {
            COMPROMISSO_CONTATOS compromissoContato = context.COMPROMISSO_CONTATOS.Where(cc => cc.IdCompromisso == idCompromisso &&
                                                                cc.IdColaborador == idUsuario &&
                                                                cc.FlagAtivo.Equals("S")).FirstOrDefault();
            string estado = compromissoContato.Estado;

            return estado;
        }

        public COMPROMISSO_CONTATOS AtualizarEstado(int idCompromisso, int idUsuario, string estado)
        {
            var compromisso = context.COMPROMISSO_CONTATOS.Where(cc=> cc.IdCompromisso == idCompromisso &&
                                                                    cc.IdColaborador == idUsuario &&
                                                                    cc.FlagAtivo.Equals("S")).FirstOrDefault();
            compromisso.Estado = estado;
            context.SaveChanges();

            return compromisso;
        }
    }

    // Carrega uma tupla de nome, email, idcompromisso, idcontato
    public class HolderEmailContato
    {
        public string Nome { get; set; }
        public string Email { get; set; }
        public int IdContato { get; set; }
    }


}