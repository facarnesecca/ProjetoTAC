﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models.Services
{
    public class NotaService
    {
        private OrganizadorPessoalContext context; 

        public NotaService() 
        {
            context = new OrganizadorPessoalContext();    
        }

        public NotaService(OrganizadorPessoalContext context) 
        {
            this.context = context;
        }

        public List<NOTA> ListarPorCompromisso(int idCompromisso)
        {
            return context.NOTA.Where(n => n.IdCompromisso.Value.Equals(idCompromisso) && n.FlagAtivo.Equals("S")).ToList();
        }

        public void Adicionar(NOTA nota)
        {
            context.NOTA.Add(nota);
            context.SaveChanges();
        }

        public List<ValidationResult> ValidaAdicionar(NOTA nota)
        {
            List<ValidationResult> erros = new List<ValidationResult>();
            if (nota.Descricao.Length > 1000)
                erros.Add(new ValidationResult(String.Empty, "A nota deve conter no máximo 1000 caracteres"));

            return erros;
        }

        public void Remover(int idNota)
        {
            var nota = context.NOTA.Find(idNota);
            nota.FlagAtivo = "N";

            context.SaveChanges();
        }
    }
}