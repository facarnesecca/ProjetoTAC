﻿using OrganizadorPessoal.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Models
{
    public class EventoFacade
    {
        private List<TAREFA> tarefas;
        private List<COMPROMISSO> compromissos;

        public EventoFacade(List<TAREFA> tarefas, List<COMPROMISSO> compromissos){
            this.tarefas = tarefas;
            this.compromissos = compromissos;
        }

        public List<Evento> OrdenarEventos(bool ordemCrescente = true)
        {
            var eventos = listarEventos(this.tarefas, this.compromissos);

            if (ordemCrescente)
                eventos.OrderBy(m => m.DataInicio).ToList();
            else
                eventos.OrderByDescending(m => m.DataInicio).ToList();

            return eventos;
        }

        private Evento converterTarefa(TAREFA tarefa) {

            Evento evento = new Evento();
            evento.Tipo = "T";
            evento.Id = tarefa.IdTarefa;
            evento.DataInicio = tarefa.DataInicio;
            evento.DataTermino = tarefa.DataTermino;
            evento.Titulo = tarefa.Titulo;

            return evento;
        }

        private Evento converterCompromisso(COMPROMISSO compromisso)
        {
            Evento evento = new Evento();
            evento.Tipo = "C";
            evento.Id = compromisso.IdCompromisso;
            evento.DataInicio = compromisso.DataInicio;
            evento.DataTermino = compromisso.DataTermino;
            evento.Titulo = compromisso.Titulo;

            return evento;
        }

        private List<Evento> listarEventos(List<TAREFA> tarefas, List<COMPROMISSO> compromissos)
        {
            List<Evento> eventos = new List<Evento>();
            foreach (var item in tarefas)
            {
                eventos.Add(converterTarefa(item));
            }
            foreach (var item in compromissos)
            {
                eventos.Add(converterCompromisso(item));
            }

            return eventos;
        }

    }
}