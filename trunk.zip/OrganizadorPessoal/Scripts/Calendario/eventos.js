﻿$(document).ready(function () { 
    function dialogoAberto() {
        return $('.dialogo.aparece').length;
    }
    function dialogoEventosAberto() {
        return $('.dialogoEventos.aparece').length;
    }
    function fechaDialogos() {
        if (dialogoAberto()) {
            $('.dialogo.aparece').removeClass('aparece').addClass('esconde');
        }
    }
    function fechaDialogosEventos() {
        if (dialogoEventosAberto()) {
            $('.dialogoEventos.aparece').removeClass('aparece').addClass('esconde');
        }
    }

    function elementoFilhoAberto(obj) {
        return $(obj).closest('.dialogoEventos').length;
    }

    $(document.body).on('click', '.evento', function (event) {
        event.stopPropagation();
        fechaDialogos();
        if (!elementoFilhoAberto($(this))) {
            fechaDialogosEventos();
        }

        $(this).children('.dialogo.esconde').removeClass('esconde').addClass('aparece');
    });

    $(document.body).on('click', '.eventosExcedentes', function (event) {
        event.stopPropagation();
        fechaDialogos();
        fechaDialogosEventos();
        $(this).children('.dialogoEventos.esconde').removeClass('esconde').addClass('aparece');
    });

    $(document.body).on('click', '.fecharDialogo', function (event) {
        event.stopPropagation();
        fechaDialogos();
    });

    $(document.body).on('click', '.fecharDialogoEventos', function (event) {
        event.stopPropagation();
        fechaDialogosEventos();
    });

    $(document.body).on('click', '#corpo', function (event) {
        if (dialogoAberto()) {
            event.stopPropagation();
            fechaDialogos();
        }

        if (dialogoEventosAberto()) {
            event.stopPropagation();
            fechaDialogosEventos();
        }
    });
});