﻿$(document).ready(function () {
    atualizaDiaSelecionado();

    //funções auxiliares

    function mesPosteriorNumero(mes) {
        var mesNum = parseInt(mes);
        if (mesNum == 12) {
            return 1;
        }
        else {
            return ++mesNum;
        }
    }

    function mesAnteriorNumero(mes) {
        var mesNum = parseInt(mes);
        if (mesNum == 1) {
            return 12;
        }
        else {
            return --mesNum;
        }
    }

    function adicionaAno() {
        $("#ano").val(parseInt($("#ano").val()) + 1);
    }

    function subtraiAno() {
        $("#ano").val(parseInt($("#ano").val()) - 1);
    }

    function adicionaMes() {
        if ($("#mes").val() != 12) {
            $("#mes").val(parseInt($("#mes").val()) + 1);
        }
        else {
            $("#mes").val(1);
            adicionaAno();
        }
    }

    function subtraiMes() {
        if ($("#mes").val() != 1) {
            $("#mes").val(parseInt($("#mes").val()) - 1);
        }
        else {
            $("#mes").val(12);
            subtraiAno();
        }
    }

    function atualizaDiaSelecionado() {
        var dia = $("#dia").val();
        var mes = $("#mes").val();
        var ano = $("#ano").val();

        $("#data").val(formatarData(dia, mes, ano));
        $("#dataApresentada").html($("#data").val().split(" ")[0]);
        $("#mesAtual").html(nomeDoMes(parseInt(mes)) + " " + ano);
        $("#mesAnterior").val(nomeDoMesAbreviado(mesAnteriorNumero(mes)));
        $("#mesPosterior").val(nomeDoMesAbreviado(mesPosteriorNumero(mes)));

        //Atualiza o campo tarefas
        atualizarTarefas();
    }

    //tratar uma data mínima pelo menos entre 1000 e 9999
    function formatarData(dia, mes, ano) {
        if (dia.length == 1) {
            dia = "0" + dia;
        }
        if (mes.length == 1) {
            mes = "0" + mes;
        }

        var data = dia + "/" + mes + "/" + ano;

        return data;
    }

    function nomeDoMes(mes) {
        var mesNumero = parseInt(mes);
        var nome = "";
        switch (mesNumero) {
            case 1:
                nome += "Janeiro";
                break;
            case 2:
                nome += "Fevereiro";
                break;
            case 3:
                nome += "Março";
                break;
            case 4:
                nome += "Abril";
                break;
            case 5:
                nome += "Maio";
                break;
            case 6:
                nome += "Junho";
                break;
            case 7:
                nome += "Julho";
                break;
            case 8:
                nome += "Agosto";
                break;
            case 9:
                nome += "Setembro";
                break;
            case 10:
                nome += "Outubro";
                break;
            case 11:
                nome += "Novembro";
                break;
            default:
                nome += "Dezembro";
                break;
        }

        return nome;
    }

    function nomeDoMesAbreviado(mes) {
        var mesNumero = parseInt(mes);
        var nome = "";
        switch (mesNumero) {
            case 1:
                nome += "Jan";
                break;
            case 2:
                nome += "Fev";
                break;
            case 3:
                nome += "Mar";
                break;
            case 4:
                nome += "Abr";
                break;
            case 5:
                nome += "Mai";
                break;
            case 6:
                nome += "Jun";
                break;
            case 7:
                nome += "Jul";
                break;
            case 8:
                nome += "Ago";
                break;
            case 9:
                nome += "Set";
                break;
            case 10:
                nome += "Out";
                break;
            case 11:
                nome += "Nov";
                break;
            default:
                nome += "Dez";
                break;
        }

        return nome;
    }

    function resgataDiaSelecionado(obj) {

        if (obj.getAttribute("data-dia") != null) {

            var objeto = obj.getAttribute("data-dia").split("/");
            $("#dia").val(objeto[0]);
            $("#mes").val(objeto[1]);
            $("#ano").val(objeto[2]);

            $("#dataEscolhida").val(obj.getAttribute("data-dia"));
            $("#dataEscolhidaCompromisso").val(obj.getAttribute("data-dia"));
            atualizaDiaSelecionado();
        }
    }

    // funções Ajax
    function atualizar() {
        $.ajax({
            type: 'POST',
            url: '/Home/_Calendario',
            dataType: 'html',
            cache: false,
            async: true,
            data:
                {
                    ano: $("#ano").val(),
                    mes: $("#mes").val(),
                    dia: $("#dia").val()
                },
            success: function (data) {
                $("#grid").html(data);
                atualizaDiaSelecionado();
            }
        });
    }

    function diaAtual() {
        $.ajax({
            type: 'POST',
            url: '/Home/_Calendario',
            dataType: 'html',
            cache: false,
            async: true,
            success: function (data) {
                $("#grid").html(data);
                atualizaDiaSelecionado();
            }
        });
    }

    // Atualizar TODO
    function atualizarTarefas() {
        $.ajax({
            type: 'POST',
            url: '/Home/_Tarefas',
            dataType: 'html',
            cache: false,
            async: true,
            success: function (data) {
                $("#grid2").html(data);
            }
        });
    }

    // fim de funções auxiliares
    //---------------------------------

    $(document.body).on('click', '.alterarMes', function (e) {
        e.preventDefault();
        if (this.id == "mesPosterior") {
            adicionaMes();
        }
        else if (this.id == "mesAnterior") {
            subtraiMes();
        }

        atualizar();
    });

    $(document.body).on('click', ".diaInativo", function (e) {
        e.preventDefault();
        resgataDiaSelecionado(this);
        atualizar();
    });

    $(document.body).on('click', ".diaAtivo", function (e) {
        e.preventDefault();

        resgataDiaSelecionado(this);
        for (var i = 0; i < 42; i++) {
            if ($("#" + i).hasClass("diaSelecionado")) {
                $("#" + i).removeClass("diaSelecionado").addClass("diaAtivo");
            }
        }
        $(this).toggleClass("diaSelecionado");
    });

    function isNotPast(diaPesquisado) {
        var dt = new Date();
        var data = dt.toLocaleDateString();
        var d = data.toString().split("/");
        var dHoje = parseInt("" + dt.getFullYear() + (dt.getMonth() + 1) + dt.getDate());

        var data1 = diaPesquisado.split("/");
        var dPesquisado = parseInt(data1[2] + data1[1] + data1[0]);

        return(dPesquisado >= dHoje);
    }

    $(document.body).on('dblclick', ".diaSelecionado", function (e) {
        e.preventDefault();
        resgataDiaSelecionado(this);
        
        if (isNotPast($(this).attr("data-dia"))) {
            $("#formCadastrarCompromisso").submit();
        }
    });

    $(document.body).on('click', '.adicionar', function (e) {
        e.preventDefault();
        var elemento = $(this);
        var elementoPai = elemento.parent().parent().parent();
        resgataDiaSelecionado(elementoPai[0]);
        $("#formCadastrar").submit();
    });

    $(document.body).on('click', ".hoje", function (e) {
        e.preventDefault();
        diaAtual();
    });

    $(document.body).on('click', '.consultar', function () {
        var dataId = $(this).attr("data-linkTarefa");
        var tipo = dataId.split('-')[0];

        $("[data-idtarefa*=" + dataId + "]").submit();
    });

});