﻿using System.Web;
using System.Web.Optimization;

namespace OrganizadorPessoal
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            BundleTable.EnableOptimizations = false;

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));
            
            //Adicionados
            bundles.Add(new ScriptBundle("~/bundles/Adicionados").Include(
                        "~/Scripts/Adicionados/bootstrap.js",
                        "~/Scripts/Adicionados/jquery.mask.js",
                        "~/Scripts/Adicionados/utilidades-2.0.js",
                        "~/Scripts/Adicionados/jquery.datetimepicker.js"));

            // JS CROP
            bundles.Add(new ScriptBundle("~/bundles/crop").Include(
                        "~/Scripts/Adicionados/jquery.crop.js"));

            //Calendario
            bundles.Add(new ScriptBundle("~/bundles/Calendario").Include(
                        "~/Scripts/Calendario/calendario.js",
                        "~/Scripts/Calendario/eventos.js"));


            // CSS
            bundles.Add(new StyleBundle("~/Content/css/estilo").Include(
                        "~/Content/css/site.css",
                        "~/Content/css/Adicionados/Tabela.css",
                        "~/Content/css/Adicionados/bootstrap.css",
                        "~/Content/css/Adicionados/bootstrap-responsive.css",
                        "~/Content/css/Calendario/calendario.css",
                        "~/Content/css/Adicionados/jquery.datetimepicker.css"));


            // CSS CROP
            bundles.Add(new StyleBundle("~/Content/css/crop").Include(
               "~/Content/css/Adicionados/crop.css",
               "~/Content/css/Adicionados/crop_customizacao.css"));



            bundles.Add(new StyleBundle("~/Content/css/jqueryui/themes/start/jqueryui").Include(
               "~/Content/css/themes/start/jquery-ui-{version}.css"));
        }
    }
}