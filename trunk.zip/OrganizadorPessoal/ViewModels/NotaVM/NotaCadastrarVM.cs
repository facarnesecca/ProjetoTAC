﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.NotaVM
{
    public class NotaCadastrarVM
    {
        [Required]
        [StringLength(100, ErrorMessage = "A Nota deve ter no máximo 1000 caracteres.")]
        public string Descricao { get; set; }

        public int IdCompromisso { get; set; }
    }
}