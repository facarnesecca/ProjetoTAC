﻿using OrganizadorPessoal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.NotaVM
{
    public class NotaIndexVM
    {
        public List<NOTA> Registros { get; set; }
    }
}