﻿using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels
{
    public class TarefaIndexVM
    {
        public List<TAREFA> ListaTarefas { get; set; }
        public string TarefaCondicao { get; set; }

        public USUARIO ColaboradorUsuario(string id)
        {
            int idTarefa = int.Parse(id);
            UsuarioService usuarioService = new UsuarioService();
            USUARIO colaborador = usuarioService.BuscarPorId(idTarefa);

            return colaborador;
        }

        public string EstadoCompleto(string estado)
        {
            string status;
            switch (estado)
            {
                case "P":
                    status = "Pendente";
                    break;
                case "R":
                    status = "Rejeitada";
                    break;
                case "A":
                    status = "Aceita";
                    break;
                default: // "C"
                    status = "Concluída";
                    break;
            }
            return status;
        }
    }
}