﻿using OrganizadorPessoal.Controllers;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels
{
    public class TarefaCadastrarVM
    {
        public string IdExecutor { get; set; }
        public string IdTarefa { get; set; }
        public string IdProprietario { get; set; }
        public string IdGrupo { get; set; }
        public string IdCompromisso { get; set; }

        [Display(Name = "* Título:")]
        [Required(ErrorMessage = "Insira um Título")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "O Título deve ter entre 5 e 20 caracteres")]
        public string Titulo { get; set; }

        [Display(Name="Atribuir tarefa")]
        public bool AtribuirTarefa { get; set; }

        [Display(Name = "Executor")]
        public string NomeExecutor { get; set; }

        [Display(Name = "* Início:")]
        [Required(ErrorMessage = "Insira uma data para o início da tarefa")]
        [DisplayFormat(DataFormatString = "dd/mm/yyy hh24:mi")]
        public string DataHoraInicio { get; set; }
        public DateTime DataHoraInicioDateTime { get; set; }

        [Display(Name = "Término?")]
        public bool DataLimite { get; set; }

        [DisplayFormat(DataFormatString = "dd/mm/yyy hh24:mi")]
        public string DataHoraTermino { get; set; }

        [Display(Name = "Descrição")]
        [StringLength(1000, ErrorMessage = "A descrição deve conter no máximo 1000 caracteres")]
        public string Descricao { get; set; }

        [Display(Name="Observação")]
        [StringLength(2000, ErrorMessage = "A descrição deve conter no máximo 2000 caracteres")]
        public string Observacao { get; set; }

        public string Estado { get; set; }

        public List<CONTATO> ContatosUsuarios { get; set; }

        public static TarefaCadastrarVM ConstruirFormParaNovo()
        {
            TarefaCadastrarVM vm = new TarefaCadastrarVM();

            // TODO melhorar essa parte de contatos usuarios
            ContatoService contatoService = new ContatoService();
            GrupoService grupoService = new GrupoService();

            var sessao = ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            vm.IdProprietario = sessao.Usuario.IdUsuario.ToString();
            vm.IdGrupo = sessao.Grupo.IdGrupo.ToString();

            vm.DataLimite = false;

            // A princípio o proprietário é o próprio executor.
            vm.AtribuirTarefa = false;
            vm.NomeExecutor = sessao.Usuario.Nome;
            vm.IdExecutor = sessao.Usuario.IdUsuario.ToString();

            vm.ContatosUsuarios = contatoService.ListarContatosUsuarios(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo);


            return vm;
        }

        public static void PopularItens(TarefaCadastrarVM vm){
            GrupoService grupoService = new GrupoService();
            ContatoService contatoService = new ContatoService();
            UsuarioService usuarioService = new UsuarioService();

            var sessao = ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            vm.IdProprietario = sessao.Usuario.IdUsuario.ToString();
            vm.IdGrupo = sessao.Grupo.IdGrupo.ToString();

            vm.ContatosUsuarios = contatoService.ListarContatosUsuarios(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo);

        }

        public static TAREFA ConverterTarefaVM(TarefaCadastrarVM vm)
        {
            TAREFA registro = new TAREFA();

            var sessao = ((SessaoUsuarioModel) HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idProprietario = sessao.Usuario.IdUsuario;
            int idGrupo = sessao.Grupo.IdGrupo;
            // Proprietario
            registro.IdProprietario = idProprietario;
            registro.IdGrupoProprietario = idGrupo;

            // Executor - Se não atribuir tarefa, o proprietário é o próprio executor
            registro.IdExecutor = vm.AtribuirTarefa  || (vm.IdCompromisso != "" && vm.IdCompromisso != null) ? int.Parse(vm.IdExecutor) : idProprietario;
            registro.IdGrupoExecutor = idGrupo;

            registro.Titulo = vm.Titulo;
            registro.DataInicio = DateTime.Parse(vm.DataHoraInicio);
            registro.DataTermino = (vm.DataLimite && vm.DataHoraTermino != null) ? 
                                        DateTime.Parse(vm.DataHoraTermino) : (DateTime?) null;
            registro.Descricao = vm.Descricao;
            registro.Observacao = vm.Observacao;

            // Compromisso associado
            int idCompromisso;
            registro.IdCompromisso = int.TryParse(vm.IdCompromisso, out idCompromisso) ? idCompromisso : (int?) null;

            return registro;
        }

        public static TarefaCadastrarVM ConverterTarefaVM(TAREFA registro)
        {
            TarefaCadastrarVM vm = new TarefaCadastrarVM();

            vm.IdTarefa = registro.IdTarefa.ToString();
            vm.Titulo = registro.Titulo;
            vm.IdProprietario = registro.IdProprietario.ToString();
            vm.IdExecutor = registro.IdExecutor.ToString();
            vm.IdGrupo = registro.IdGrupoProprietario.ToString();
            vm.Estado = registro.Estado;

            vm.DataHoraInicio = registro.DataInicio.ToString("dddd', 'dd 'de' MMMM 'de' yyyy 'às' HH'h'mm");
            vm.DataHoraInicioDateTime = registro.DataInicio;
            vm.DataHoraTermino = registro.DataTermino != null ? registro.DataTermino.Value.ToString("dddd', 'dd 'de' MMMM 'de' yyyy 'às' HH'h'mm") : "";

            vm.Descricao = registro.Descricao;
            vm.Observacao = registro.Observacao;
            // Observações

            // Compromisso associado
            vm.IdCompromisso = registro.IdCompromisso != null ? registro.IdCompromisso.Value.ToString() : "";

            return vm;
        }

        public USUARIO ProprietarioTarefa(string id)
        {
            int idTarefa = int.Parse(id);
            UsuarioService usuarioService = new UsuarioService();
            USUARIO proprietario = usuarioService.BuscarPorId(idTarefa);

            return proprietario;
        }

        public bool UsuarioExecutor(string idExecutor)
        {
            return ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]).Usuario.IdUsuario == int.Parse(idExecutor);
        }

        public USUARIO BuscaUsuario(string id)
        {
            int idUsuario = int.Parse(id);
            UsuarioService usuarioService = new UsuarioService();
            USUARIO usuario = usuarioService.BuscarPorId(idUsuario);

            return usuario;
        }

        public COMPROMISSO BuscarCompromisso(string id)
        {
            int idCompromisso = int.Parse(id);
            CompromissoService compromissoService = new CompromissoService();
            COMPROMISSO compromisso = compromissoService.BuscarPorId(idCompromisso);

            return compromisso;
        }

        public string EstadoCompleto(string estado)
        {
            string status;
            switch (estado)
            {
                case "P":
                    status = "Pendente";
                    break;
                case "R":
                    status = "Rejeitada";
                    break;
                case "A":
                    status = "Aceita";
                    break;
                default: // "C"
                    status = "Concluída";
                    break;
            }
            return status;
        }
    }
}