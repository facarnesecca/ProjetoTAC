﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OrganizadorPessoal.Models;

namespace OrganizadorPessoal.ViewModels.GrupoVM
{
    public class GrupoListaUsuariosVM
    {
        public List<USUARIO> ListaUsuarios { get; set; }
    }
}