﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.GrupoVM
{
    public class GrupoCadastrarVM
    {
        [Required(ErrorMessage="Insira o nome do grupo.")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "O Nome do Grupo deve ter entre 3 e 20 caracteres.")]
        [Display(Name="* Nome:")]
        public string Nome { get; set; }

        public string ImagemGrupoBase64 { get; set; }

        [Required(ErrorMessage="Insira o e-mail do administrador.")]
        [StringLength(150 ,MinimumLength = 5, ErrorMessage = "O E-mail deve ter no mínimo entre 5 e 150 caracteres.")]
        [DataType(DataType.EmailAddress)]
        [EmailAddress(ErrorMessage="E-mail inválido")]
        [Display(Name = "* E-mail do Administrador:")]
        public string EmailAdmin { get; set; }
    }
}