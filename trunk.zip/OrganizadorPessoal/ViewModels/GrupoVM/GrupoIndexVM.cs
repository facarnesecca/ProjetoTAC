﻿using OrganizadorPessoal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.GrupoVM
{
    public class GrupoIndexVM
    {
        public List<GRUPO> Registros { get; set; }

    }
}