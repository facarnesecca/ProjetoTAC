﻿using OrganizadorPessoal.Controllers;
using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels
{
    public class EventoVM
    {
        public List<TAREFA> ListaTarefa { get; set; }
        public List<COMPROMISSO> ListaCompromisso { get; set; }
        public List<COMPROMISSO_CONTATOS> ListaCompromissosContatos { get; set; }
        public Tuple<List<TAREFA>, List<COMPROMISSO>> TuplaTarefasCompromissos { get; set; }

        [DataType(DataType.Date, ErrorMessage="Insira uma data válida")]
        public string Data { get; set; }


        public EventoVM()
        {
            ListaTarefa = new List<TAREFA>();
            ListaCompromisso = new List<COMPROMISSO>();
            ListaCompromissosContatos = new List<COMPROMISSO_CONTATOS>();
        }

        public EventoVM(int idUsuario, int idGrupo, bool proprietario)
        {
            TarefaService tarefaService = new TarefaService();
            CompromissoService compromissoService = new CompromissoService();
            if(proprietario)
            {
                ListaTarefa = tarefaService.ListarTarefasDelegadas(idUsuario, idGrupo).OrderBy(m=>m.DataInicio).ToList();
                ListaCompromisso = compromissoService.ListarCompromissosProprietario(idUsuario, idGrupo).OrderBy(m => m.DataInicio).ToList();
            }
            else
            {
                ListaTarefa = tarefaService.ListarTarefasExecutor(idUsuario, idGrupo).OrderBy(m => m.DataInicio).ToList();
                ListaCompromisso = compromissoService.ListarCompromissos(idUsuario, idGrupo).OrderBy(m => m.DataInicio).ToList();
            }
        }

        public EventoVM(int idUsuario, int idGrupo, DateTime dataInicio)
        {
            TarefaService tarefaService = new TarefaService();
            ListaTarefa = tarefaService.ListarTarefasPorData(idUsuario, idGrupo, dataInicio);
            // Listar Compromisso
        }

        public string EstadoCompleto(string estado)
        {
            string status;
            switch (estado)
            {
                case "P":
                    status = "Pendente";
                    break;
                case "R":
                    status = "Rejeitada";
                    break;
                case "A":
                    status = "Aceita";
                    break;
                default: // "C"
                    status = "Concluída";
                    break;
            }
            return status;
        }

        // Alterar
        public Tuple<List<TAREFA>, List<COMPROMISSO>> ListarEventosPorDia(DateTime dataPesquisa)
        {
            var sessao = ((SessaoUsuarioModel) HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);


            int idUsuario = sessao.Usuario.IdUsuario;
            int idGrupo = sessao.Grupo.IdGrupo;

            

            TarefaService tarefaService = new TarefaService();
            List<TAREFA> tarefas = tarefaService.ListarTarefasAceitasDoDia(idUsuario, idGrupo, dataPesquisa);

            CompromissoService compromissoService = new CompromissoService();
            List<COMPROMISSO> compromissos = compromissoService.ListarCompromissosAceitosDoDia(idUsuario, idGrupo, dataPesquisa);

            tarefas.OrderBy(d => d.DataInicio);
            compromissos.OrderBy(d => d.DataInicio);

            TuplaTarefasCompromissos = new Tuple<List<TAREFA>, List<COMPROMISSO>>(tarefas, compromissos);


            return TuplaTarefasCompromissos;
        }

        public USUARIO UsuariorTarefa(int? idUsuario)
        {
            UsuarioService usuarioService = new UsuarioService();
            USUARIO executor = usuarioService.BuscarPorId(idUsuario.Value);

            return executor;
        }
    }

    public class ComparaEventos : IComparer<DateTime>
    {

        public int Compare(DateTime x, DateTime y)
        {
            if (x == null)
            {
                if (y == null)
                {
                    // If x is null and y is null, they're 
                    // equal.  
                    return 0;
                }
                else
                {
                    // If x is null and y is not null, y 
                    // is greater.  
                    return -1;
                }
            }
            else
            {
                // If x is not null... 
                // 
                if (y == null)
                // ...and y is null, x is greater.
                {
                    return 1;
                }
                else
                {
                    // ...and y is not null, compare the  
                    // lengths of the two strings. 
                    // 
                    int retval = x.CompareTo(y);

                    if (retval != 0)
                    {
                        // If the strings are not of equal length, 
                        // the longer string is greater. 
                        // 
                        return retval;
                    }
                    else
                    {
                        // If the strings are of equal length, 
                        // sort them with ordinary string comparison. 
                        // 
                        return x.CompareTo(y);
                    }
                }
            }
        }
    }
}