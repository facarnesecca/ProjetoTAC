﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OrganizadorPessoal.Controllers;
using System.ComponentModel.DataAnnotations;

namespace OrganizadorPessoal.ViewModels
{
    public class EventoBuscarVM
    {
        public List<Evento> Eventos { get; set; }

        [Display(Name="* Data: ")]
        [Required(ErrorMessage="Insira uma data")]
        public string DataBusca { get; set; }
    }
}