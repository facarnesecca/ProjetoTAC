﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.AutenticacaoVM
{
    public class AutenticacaoLogarVM
    {
        [Required(ErrorMessage = "Insira o e-mail.")]
        [StringLength(150, MinimumLength = 5, ErrorMessage = "O e-mail deve ter de 5 a 150 caracteres.")]
        [Display(Name = "E-mail")]
        [EmailAddress(ErrorMessage = "Insira um e-mail no formato correto.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Insira a senha.")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "A senha deve ter de 5 a 20 caracteres.")]
        public string Senha { get; set; }
    }
}