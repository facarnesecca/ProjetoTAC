﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OrganizadorPessoal.Models;

namespace OrganizadorPessoal.ViewModels.MeuGrupoVM
{
    public class MeuGrupoIndex
    {
        public List<USUARIO> ListaUsuario { get; set; }
        public GRUPO GrupoSessao { get; set; }
        public USUARIO UsuarioSessao { get; set; }
    }
}