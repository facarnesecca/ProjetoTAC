﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.UsuarioVM
{
    public class UsuarioRegistrarVM
    {
        public string Email { get; set; }

        [Required(ErrorMessage = "Insira o nome.")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "O nome deve ter de 5 a 100 caracteres.")]
        [Display(Name = "* Nome:")]
        public string Nome { get; set; }

        [StringLength(14, MinimumLength = 13, ErrorMessage = "Insira o telefone corretamente.")]
        [Display(Name = "Telefone:")]
        public string Telefone { get; set; }

        [StringLength(100, ErrorMessage = "O endereço deve ter no máximo 100 caracteres.")]
        [Display(Name = "Endereço:")]
        public string Endereco { get; set; }

        public string FotoUsuarioBase64 { get; set; }

        [Required(ErrorMessage = "Insira a senha.")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "A senha deve ter de 5 a 20 caracteres.")]
        [Display(Name = "* Senha:")]
        public string Senha { get; set; }

        [Required(ErrorMessage = "Insira a senha.")]
        [StringLength(20, MinimumLength = 5, ErrorMessage = "A senha deve ter de 5 a 20 caracteres.")]
        [Compare("Senha", ErrorMessage = "Insira a confirmação igual a senha.")]
        [Display(Name= "* Confirme a senha:")]
        public string SenhaConfirmacao { get; set; }
    }
}