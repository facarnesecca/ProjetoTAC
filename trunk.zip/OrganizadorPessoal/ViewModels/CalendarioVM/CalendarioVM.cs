﻿using OrganizadorPessoal.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels
{
    public class CalendarioVM
    {
        public int Dia { get; set; }
        public int Mes { get; set; }
        public int Ano { get; set; }

        public DateTime Data { get; set; }
        public List<DateTime> DatasDoMes { get; set; }
        //public EventosVM Eventos { get; set; }
        public EventoVM Evento { get; set; }
        public CalendarioVM()
        {
            Dia = DateTime.Now.Day;
            Mes = DateTime.Now.Month;
            Ano = DateTime.Now.Year;
            Data = new DateTime(Ano, Mes, Dia);

            DatasDoMes = GerarCalendarioData(Ano, Mes);
            //Eventos = new EventosVM(Ano, Mes);
            var sessao = ((SessaoUsuarioModel) HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            //Evento = new EventoVM(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo, Ano, Mes);
            Evento = new EventoVM();
        }

        public CalendarioVM(int ano, int mes, int dia)
        {

            Dia = dia;
            Mes = mes;
            Ano = ano;

            DatasDoMes = GerarCalendarioData(Ano, Mes);
            //Eventos = new EventosVM(Ano, Mes);
            Evento = new EventoVM();

            var sessao = ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);
            //Evento = new EventoVM(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo, Ano, Mes); 
            Evento = new EventoVM(); 

            bool dataInvalida = false;
            do
            {
                try
                {
                    Data = new DateTime(Ano, Mes, Dia);
                    break;
                }
                catch (Exception)
                {
                    Dia--;
                    dataInvalida = true;
                }
            } while (dataInvalida);

        }

        private string formatarData(int dia, int mes, int ano)
        {
            string data = "";
            data += dia < 10 ? "0" + dia : "" + dia;
            data += "/";
            data += mes < 10 ? "0" + mes : "" + mes;
            data += "/";
            data += ano;

            return data;
        }

        //Retorna a folhinha do mês
        public static List<DateTime> GerarCalendarioData(int ano, int mes)
        {
            List<DateTime> dias = new List<DateTime>();
            int numeroDias = DateTime.DaysInMonth(ano, mes);
            int numeroDiasMesAnterior = mes > 1 ? DateTime.DaysInMonth(ano, mes - 1) : DateTime.DaysInMonth(ano - 1, 12);

            DateTime Calendario = new DateTime(ano, mes, 1);

            int diasAnteriores;
            switch (Calendario.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    diasAnteriores = 1;
                    break;
                case DayOfWeek.Tuesday:
                    diasAnteriores = 2;
                    break;
                case DayOfWeek.Wednesday:
                    diasAnteriores = 3;
                    break;
                case DayOfWeek.Thursday:
                    diasAnteriores = 4;
                    break;
                case DayOfWeek.Friday:
                    diasAnteriores = 5;
                    break;
                case DayOfWeek.Saturday:
                    diasAnteriores = 6;
                    break;
                default: //DayOfWeek.Sunday:
                    diasAnteriores = 7;
                    break;
            }

            int diasAnt = diasAnteriores;
            //Gera datas do mes anterior
            while (diasAnt > 0)
            {
                DateTime diaDoMesAnterior = Calendario.Subtract(TimeSpan.FromDays(diasAnt));
                dias.Add(diaDoMesAnterior);

                diasAnt--;
            }

            int diasNoMes = DateTime.DaysInMonth(Calendario.Year, Calendario.Month);
            for (int i = 0; i < diasNoMes; i++)
            {
                dias.Add(Calendario.AddDays(i));
            }

            // A folha do mês completa tem 42 datas
            int diasPosteriores = 42 - diasAnteriores - diasNoMes;

            for (int i = 0; i < diasPosteriores; i++)
            {
                dias.Add(Calendario.AddMonths(1).AddDays(i));
            }
            return dias;
        }
    }
}