﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels
{
    public class EventosVM
    {

        // TODO remover toda esta classe - foi utilizada apenas na implementação

        // Armazena uma lista <data, Título do evento>
        // TODO Substituir por classes equivalentes
        public List<Tuple<DateTime, String>> ListaDateTimeTarefas { get; set; }
        public DateTime Horario { get; set; }

        public EventosVM()
        {
            
        }

        // Esta função apenas gera eventos aleatórios de acordo com o dia
        // TODO - substituir quando o construtor correto estiver implementado
        public EventosVM(int ano, int mes)
        {
            ListaDateTimeTarefas = new List<Tuple<DateTime, string>>();
            Random random = new Random();

            int qtd = random.Next(0, 100);
            for (int i = 0; i < qtd; i++)
            {
                int dia = random.Next(1, 28);
                this.ListaDateTimeTarefas.Add(
                    new Tuple<DateTime, string>(
                        new DateTime(ano, mes, dia),
                        "Tarefa " + (i + 1)));
            }
        }

        // Construtor a ser usado para buscar as tarefas de acordo com as datas do calendário do mês selecionado
        public EventosVM(List<DateTime> datasDoMes)
        {
            //ListaDateTimeTarefas = buscaTarefas(datasDoMes)

        }
        // TODO Melhorar os construtores
        public EventosVM(List<Tuple<DateTime, String>> listaDateTimeTarefas)
        {
            ListaDateTimeTarefas = listaDateTimeTarefas;
        } 
    }
}