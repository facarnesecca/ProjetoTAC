﻿using OrganizadorPessoal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.ContatoVM
{
    public class ContatoIndexVM
    {
        public List<CONTATO> ListaContato { get; set; }
    }
}