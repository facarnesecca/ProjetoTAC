﻿using OrganizadorPessoal.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels.ContatoVM
{
    public class ContatoCadastrarVM
    {
        [Required(ErrorMessage = "Informe o nome.")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "O Nome deve ter entre 5 e 100 caracteres.")]
        [Display(Name = "* Nome:")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Informe o e-mail.")]
        [StringLength(50, MinimumLength = 12, ErrorMessage = "O Email deverá ter no mínimo 12 caracteres.")]
        [Display(Name = "* E-mail:")]
        [EmailAddress(ErrorMessage = "E-mail inválido")]
        public string Email { get; set; }

        [StringLength(100, ErrorMessage = "O Endereço deverá ter no máximo 100 caracteres.")]
        [Display(Name = "Endereço:")]
        public string Endereco { get; set; }

        [StringLength(14, MinimumLength = 13, ErrorMessage = "Insira o telefone corretamente.")]
        public string Telefone { get; set; }

        [Display(Name = "Convidar contato para o grupo? ")]
        public bool ConvidarParaOgrupo { get; set; }

        [Display(Name = "Poderá convidar novos membros para o grupo? ")]
        public bool PermitirConvidarMembros { get; set; }

        [Display(Name = "* Data de Nascimento:")]
        [Required(ErrorMessage = "Insira a data de nascimento")]
        [DisplayFormat(DataFormatString = "dd/mm/yyy")]
        public string DataNascimeto { get; set; }

        [StringLength(50, ErrorMessage = "O Apelido deve ter no máximo 50 caracteres.")]
        [Display(Name = "Apelido:")]
        public string Apelido { get; set; }

}
}