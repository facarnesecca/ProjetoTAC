﻿using System;
using OrganizadorPessoal.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using OrganizadorPessoal.Models.Services;
using OrganizadorPessoal.Controllers;

namespace OrganizadorPessoal.ViewModels
{
    public class CompromissoCadastrarVM
    {
        public string IdCompromisso { get; set; }
        public string IdProprietario { get; set; }
        public string IdGrupo { get; set; }

        [Display(Name="* Título:")]
        [Required(ErrorMessage="Insira um título")]
        [StringLength(20, MinimumLength=5, ErrorMessage="O título deve ter entre 5 e 20 caracteres")]
        public string Titulo { get; set; }

        [Display(Name="Descrição:")]
        [StringLength(1000, ErrorMessage="A descrição deve conter no máximo 1000 caracteres")]
        public string Descricao { get; set; }

        [Display(Name="* Início:")]
        [Required(ErrorMessage="Insira uma data para o início do compromisso")]
        [DisplayFormat(DataFormatString = "dd/mm/yyy hh24:mi")]
        public string DataHoraInicio { get; set; }
        public DateTime DataHoraInicioDateTime { get; set; }

        [Display(Name = "* Término:")]
        [Required(ErrorMessage = "Insira uma data para o término do compromisso")]
        [DisplayFormat(DataFormatString = "dd/mm/yyy hh24:mi")]
        public string DataHoraTermino { get; set; }
        public DateTime DataHoraTerminoDateTime { get; set; }

        [Display(Name="Adicionar colaboradores")]
        public bool AdicionarColaboradores { get; set; }

        // Lista de contatos
        public List<CONTATO> Contatos { get; set; }
        public List<COMPROMISSO_CONTATOS> CompromissosContatos { get; set; }

        public List<NOTA> Notas { get; set; }

        public CompromissoCadastrarVM()
        {
            CompromissosContatos = new List<COMPROMISSO_CONTATOS>();
            Contatos = new List<CONTATO>();
            Notas = new List<NOTA>();
        }

        public void AdicionarColaborador(string id)
        {
            ContatoService contatoService = new ContatoService();
            CONTATO contato = contatoService.Detalhes(int.Parse(id));

            Contatos.Add(contato);
        }

        public static CompromissoCadastrarVM ConstruirFormParaNovo()
        {
            CompromissoCadastrarVM vm = new CompromissoCadastrarVM();

            ContatoService contatoService = new ContatoService();
            GrupoService grupoService = new GrupoService();

            var sessao = ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            vm.IdProprietario = sessao.Usuario.IdUsuario.ToString();
            vm.IdGrupo = sessao.Grupo.IdGrupo.ToString();
            vm.AdicionarColaboradores = false;
            vm.Contatos = contatoService.Listar(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo);

            return vm;
        }

        public static void PopularItens(CompromissoCadastrarVM vm)
        {
            GrupoService grupoService = new GrupoService();
            ContatoService contatoService = new ContatoService();

            var sessao = ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            vm.IdProprietario = sessao.Usuario.IdUsuario.ToString();
            vm.IdGrupo = sessao.Grupo.IdGrupo.ToString();
            vm.Contatos = contatoService.Listar(sessao.Usuario.IdUsuario, sessao.Grupo.IdGrupo);

        }

        public static COMPROMISSO ConverterCompromissoVM(CompromissoCadastrarVM vm)
        {
            COMPROMISSO registro = new COMPROMISSO();

            var sessao = ((SessaoUsuarioModel)HttpContext.Current.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR]);

            int idProprietario = sessao.Usuario.IdUsuario;
            int idGrupo = sessao.Grupo.IdGrupo;
            // Proprietario
            registro.IdProprietario = idProprietario;
            registro.IdGrupo = idGrupo;
            int idCompromisso;
            registro.IdCompromisso = int.TryParse(vm.IdCompromisso, out idCompromisso) ? idCompromisso : 0;

            registro.Titulo = vm.Titulo;
            registro.DataInicio = DateTime.Parse(vm.DataHoraInicio);
            registro.DataTermino = DateTime.Parse(vm.DataHoraTermino);
            registro.Descricao = vm.Descricao;

            return registro;
        }

        public static CompromissoCadastrarVM ConverterCompromissoVM(COMPROMISSO registro)
        {
            CompromissoCadastrarVM vm = new CompromissoCadastrarVM();

            vm.IdCompromisso = registro.IdCompromisso.ToString();
            vm.IdProprietario = registro.IdProprietario.ToString();
            vm.IdGrupo = registro.IdGrupo.ToString();
            vm.Titulo = registro.Titulo;
            vm.DataHoraInicio = registro.DataInicio.ToString("dddd', 'dd 'de' MMMM 'de' yyyy 'às' HH'h'mm");
            vm.DataHoraInicioDateTime = registro.DataInicio;
            vm.DataHoraTermino = registro.DataTermino.ToString("dddd', 'dd 'de' MMMM 'de' yyyy 'às' HH'h'mm");
            vm.DataHoraTerminoDateTime = registro.DataTermino;
            vm.Descricao = registro.Descricao;
            vm.CompromissosContatos = registro.COMPROMISSO_CONTATOS.Where(cc=>cc.FlagAtivo.Equals("S")).ToList();
            vm.AdicionarColaboradores = vm.CompromissosContatos.Count > 0 ? true : false;

            return vm;
        }

        public USUARIO ProprietarioCompromisso(string id)
        {
            int idTarefa = int.Parse(id);
            UsuarioService usuarioService = new UsuarioService();
            USUARIO proprietario = usuarioService.BuscarPorId(idTarefa);

            return proprietario;
        }

        public string EstadoCompleto(string estado)
        {
            string status;
            switch (estado)
            {
                case "P":
                    status = "Pendente";
                    break;
                case "R":
                    status = "Rejeitado";
                    break;
                case "A":
                    status = "Aceito";
                    break;
                default: // "C"
                    status = "Concluído";
                    break;
            }
            return status;
        }
    }
}