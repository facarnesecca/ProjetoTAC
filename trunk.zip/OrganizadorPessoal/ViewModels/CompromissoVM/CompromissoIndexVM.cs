﻿using OrganizadorPessoal.Models;
using OrganizadorPessoal.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.ViewModels
{
    public class CompromissoIndexVM
    {
        public List<COMPROMISSO> ListaCompromissos { get; set; }
        public bool GerenciarCompromisso { get; set; }

        public USUARIO Proprietario(string id)
        {
            int idProprietario = int.Parse(id);
            UsuarioService usuarioService = new UsuarioService();
            USUARIO proprietario = usuarioService.BuscarPorId(idProprietario);

            return proprietario;
        }

        public string EstadoCompleto(string estado)
        {
            string status;
            switch (estado)
            {
                case "P":
                    status = "Pendente";
                    break;
                case "R":
                    status = "Rejeitado";
                    break;
                case "A":
                    status = "Aceito";
                    break;
                default: // "C"
                    status = "Concluído";
                    break;
            }
            return status;
        }
    }
}