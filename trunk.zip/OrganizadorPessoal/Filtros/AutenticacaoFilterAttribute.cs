﻿using OrganizadorPessoal.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace OrganizadorPessoal.Filtros
{
    public class AutenticacaoFilterAttribute : ActionFilterAttribute
    {
        // Indica o cargo(s), função(es) que o filtro deverá permitir o acesso
        public string Niveis { get; set; }

        /// <summary>
        /// Papeis:
        /// A = Somente Adminstrador do Sistema 
        /// C = Somente Usuários Comuns
        /// T = Todos
        /// </summary>
        /// <param name="papeis"></param>
        public AutenticacaoFilterAttribute(string papeis = "C")
        {
            Niveis = papeis;
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // Se a action estiver transportando um descritor do tipo PermitirAnonimos, 
            // Então libera o acesso sem precisar passar pela autenticação
            object[] descritoresPermitemAnonimos =
                filterContext.ActionDescriptor.GetCustomAttributes(typeof(PermitirAnonimosAttribute), true);

            if (descritoresPermitemAnonimos.Count() == 0)
            {
                
                bool filtroAtivo = true;

                if (filtroAtivo)
                {

                    SessaoUsuarioModel usuarioSessao = (SessaoUsuarioModel) filterContext.HttpContext.Session[SessaoUsuarioModel.KEY_IDENTIFICADOR];


                    // Força o usuário a escolher um grupo 
                    if (usuarioSessao != null && usuarioSessao.Usuario != null)
                    {
                        bool ehAdmSistema = usuarioSessao.Usuario.AdmSistema.Equals("S");
                        if (ehAdmSistema)
                        {
                            string aNiveis = Niveis.ToUpper();
                            if (aNiveis.Contains("A") || aNiveis.Contains("T"))
                            {
                                // Libera o acesso sem precisar escolher o grupo e caso seja uma tela do adm pepe
                                base.OnActionExecuting(filterContext);
                            }
                            else
                            {
                                // Redireciona para a tela de grupo caso o adm tente acessar uma página fora de seu escopo
                                filterContext.Result = new RedirectToRouteResult(
                                    new RouteValueDictionary(new { controller = "Grupo", action = "Index" }));
                            }

                            
                        }
                        else
                        {
                            // Se for um usuário comum ele precisa escolher um grupo

                            if (usuarioSessao.Grupo != null)
                            {
                                
                                string aNiveis = Niveis.ToUpper();
                                if (aNiveis.Contains("C") || aNiveis.Contains("T"))
                                {
                                    // Libera o acesso caso o usuário comum tente acessar uma página dentro de seu escopo
                                    base.OnActionExecuting(filterContext);
                                }
                                else
                                {
                                    // Senão redireciona para a home
                                    filterContext.Result = new RedirectToRouteResult(
                                    new RouteValueDictionary(new { controller = "Home", action = "Index" }));
                                }
                                    
                                
                            }
                            else
                            {
                                filterContext.Result = new RedirectToRouteResult(
                                    new RouteValueDictionary(new { controller = "Autenticacao", action = "EscolherGrupo" }));
                            }
                        }


                    }
                    else
                    {
                        // Url onde o usuário estava tentando acessar
                        string url = filterContext.HttpContext.Request.Url.PathAndQuery;

                        filterContext.Result = new RedirectToRouteResult(
                            new RouteValueDictionary(new { controller = "Autenticacao", action = "Logar", url = url }));
                    }
                }
                else
                {
                    base.OnActionExecuting(filterContext);
                }
            }
            else
            {
                base.OnActionExecuting(filterContext);
            }


        }

    }
}