﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrganizadorPessoal.Filtros
{
    /**
      * Indica que a classe ou action que ativar essa marcação 
      * não precisará passar pelo esquema de autenticação
      *
      */
    public class PermitirAnonimosAttribute : Attribute
    {
    }
}